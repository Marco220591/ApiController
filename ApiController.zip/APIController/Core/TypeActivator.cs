﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;

namespace APIController.Core
{
    public static class TypeActivator
    {

        public delegate void SetParametersDelegate(IDictionary<string, object> publicParameters, IDictionary<string, object> privateParameters, string key);

        public delegate T ObjectActivator<T>(params object[] args);

        public static ObjectActivator<T> GetActivator<T>  (ConstructorInfo ctor)
        {
            //Type type = ctor.DeclaringType;
            ParameterInfo[] paramsInfo = ctor.GetParameters();

            //create a single param of type object[]
            ParameterExpression param = Expression.Parameter(typeof(object[]), "args");

            Expression[] argsExp = new Expression[paramsInfo.Length];

            //pick each arg from the params array 
            //and create a typed expression of them
            for (int i = 0; i < paramsInfo.Length; i++)
            {
                Expression index = Expression.Constant(i);
                Type paramType = paramsInfo[i].ParameterType;

                Expression paramAccessorExp = Expression.ArrayIndex(param, index);

                Expression paramCastExp = Expression.Convert(paramAccessorExp, paramType);

                argsExp[i] = paramCastExp;
            }

            //make a NewExpression that calls the
            //ctor with the args we just created
            NewExpression newExp = Expression.New(ctor, argsExp);

            //create a lambda with the New
            //Expression as body and our param object[] as arg
            LambdaExpression lambda = Expression.Lambda(typeof(ObjectActivator<T>), newExp, param);

            //compile it
            ObjectActivator<T> compiled = (ObjectActivator<T>)lambda.Compile();
            return compiled;
        }

        //public static Func<TBase> Create<TBase>(Type instanceType) where TBase : class
        //{
        //    //NewExpression newInstanceExpression = Expression.New(instanceType);
        //    //return Expression.Lambda<Func<TBase>>(newInstanceExpression).Compile();
        //    return Creator<TBase>(instanceType);
        //}

        //static Func<TBase> Creator<TBase>(Type t)
        //{
        //    if (t == typeof(string))
        //        return Expression.Lambda<Func<TBase>>(Expression.Constant(string.Empty)).Compile();

        //    if (t.HasDefaultConstructor())
        //        return Expression.Lambda<Func<TBase>>(Expression.New(t)).Compile();

        //    return () => (TBase)FormatterServices.GetUninitializedObject(t);
        //}

        //public static Func<TInstance> Create<TInstance>() where TInstance : class
        //{
        //    return Create<TInstance>(typeof(TInstance));
        //}

        //public static Func<object> Create(Type instanceType)
        //{
        //    return Create<object>(instanceType);
        //}

        //public static bool HasDefaultConstructor(this Type t)
        //{
        //    return t.IsValueType || t.GetConstructor(Type.EmptyTypes) != null;
        //}        
    }
}