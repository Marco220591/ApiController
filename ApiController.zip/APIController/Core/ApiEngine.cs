﻿using APIController.Models.Core;
using System;
using System.Collections.Concurrent;
using System.Net.Http;
using System.Web.Http;
using APIController.Handlers;
using CxUtilities.DataConection;
using Dapper;
using System.Web.Http.Routing;
using System.Linq;
using System.Collections.Generic;
using System.Configuration;
using CxUtilities.Extensions;
using System.Text.RegularExpressions;
using CxUtilities.Logger;
using System.Web.Http.Dispatcher;
using System.Data.Common;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace APIController.Core
{
    public class ApiEngine
    {
        internal static readonly string _tag = "APE";
        internal static readonly string _source = "APIEngine";
        internal const string _apiPath = "apiObj";
        private static ConcurrentBag<Tuple<string, FileInfo, FileVersionInfo>> _assembliesFiles = new ConcurrentBag<Tuple<string, FileInfo, FileVersionInfo>>();
        private static string _connectionName;
        private static ApiEngine _instance;        
        private static HttpConfiguration _config;
        private static List<ApiAssembly> _assemblies;        
        private ApiRouteHandler _routeHandler;
        private ApiAssembliesResolver _assemblyResolver;
        private List<ApiPath> _apis;
        private static object _lock = new object();
        private Timer _selfHealingTimer = null;
        private bool _selfHealingEnabled = false;
        private int _recoveryCount = 0;

        //private ApiControllerResolver _controllerResolver;

        private ApiEngine(string connectionName, HttpConfiguration config)
        {
            _connectionName = connectionName;
            _config = config;            
            _routeHandler = new ApiRouteHandler(this,config);
        }        

        public static ApiEngine GetInstance(string connectionName, HttpConfiguration config)
        {
            if (_instance == null)
            {
                _instance = new ApiEngine(connectionName, config);
                _instance.Initialize();
            }
            else
            {
                if (_assemblies == null)
                {                        
                    _instance.Initialize();
                }
            }

            return _instance;
        }

        #region Private Methods

        private static void InitFileDiscovery()
        {
            var disc = Stopwatch.StartNew();

            DiscoverAssemblies(new DirectoryInfo(System.Web.Hosting.HostingEnvironment.MapPath(GlobalInfo.AssemblyDirectory)));
            //DiscoverAssemblies(new DirectoryInfo(System.Web.Hosting.HostingEnvironment.MapPath(GlobalInfo.DependenciesDirectory))); //Dependencies is inside relativeSearchPath Bin Directory
            DiscoverAssemblies(new DirectoryInfo(AppDomain.CurrentDomain.RelativeSearchPath));

            disc.Stop();

            CxLog.Debug(_tag, _source,
                "Assemblies Discovery finished after: " + disc.ElapsedMilliseconds.ToString() + " ms. : Count: " + _assembliesFiles.Count + " : " +
                GlobalInfo.SystemName);
        }


        private static void DiscoverAssemblies(DirectoryInfo path)
        {
            try
            {
                var files = path.GetFiles().Where(f => f.Extension.Equals(".dll", StringComparison.Ordinal));

                //var files = path.EnumerateFiles("*.dll", SearchOption.AllDirectories);            

                Parallel.ForEach(files, f =>
                {
                    try
                    {
                        FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(f.FullName);
                        _assembliesFiles.Add(new Tuple<string, FileInfo, FileVersionInfo>(f.FullName, f, fvi));
                    }
                    catch (Exception exc)
                    {
                        CxLog.Warn(_tag, _source,"couldn't GetVersionInfo of: " + f.FullName + " : " + GlobalInfo.SystemName, exc);
                    }
                });

                Parallel.ForEach(path.GetDirectories(), DiscoverAssemblies);
            }
            catch (System.Exception ex)
            {
                CxLog.Warn(_tag, _source, "DiscoverAssemblies method failed! => " + path.FullName + " : " + GlobalInfo.SystemName, ex);
            }
        }

        private DbConnection GetDbConnection()
        {
            DbConnection dbConn = null;

            try
            {
                dbConn = CxConnection.CreateDbConnectionByName(_connectionName);

            }
            catch (Exception e)
            {
                CxLog.Error(_tag, _source, e);
            }

            return dbConn;
        }

        private void Initialize()
        {            
            CxLog.Debug(_tag, _source, "Initializing API Engine at: " + GlobalInfo.SystemName);

            //Discover all application assembly files and dependencies
            InitFileDiscovery();

            if (_routeHandler == null || _config == null)
            {
                CxLog.Error(_tag, _source, new Exception("API Engine properties are not initialized, restart the service. " + GlobalInfo.SystemName));
                return;
            }

            var dbConn = GetDbConnection();
            var cmd = dbConn.CreateCommand();
            cmd.CommandText = "SELECT * FROM cnxadm.APIPathTbl;SELECT * FROM cnxadm.APIPathParameterTbl;SELECT * FROM cnxadm.APIParameterTbl";
            dbConn.Open();

            IEnumerable<ApiPath> apis;
            IEnumerable<ApiParameterRel> relations;
            IEnumerable<ApiParameter> parameters;

            var apit = Stopwatch.StartNew();
            cmd.Execute(out apis)
                .Execute(out relations)
                .Execute(out parameters)
                .Close();

            apit.Stop();

            CxLog.Debug(ApiEngine._tag, ApiEngine._source,
                "Read API Path Configuration took: " + apit.ElapsedMilliseconds.ToString() + " ms. : " + GlobalInfo.SystemName);

            dbConn.Close();

            apit = Stopwatch.StartNew();

            foreach (var relation in relations)
            {
                relation.Parameter = parameters.First(p => p.APIParameterId == relation.APIParameterId);
            }

            apit.Stop();

            CxLog.Debug(ApiEngine._tag, ApiEngine._source,
                "Build API Path Relations took: " + apit.ElapsedMilliseconds.ToString() + " ms. : " + GlobalInfo.SystemName);


            apit = Stopwatch.StartNew();
            var apiPaths = apis as IList<ApiPath> ?? apis.ToList();

            foreach (var api in apiPaths)
            {
                //api.References = relations.Where(r => r.APIPathId == api.APIPathId && r.IO == "O").ToArray();
                try
                {
                    api.PublicParams = relations.Where(r => r.APIPathId == api.APIPathId && r.IO == "O").ToDictionary(r => r.Parameter.ParameterName, r => r.Parameter.ParameterDescription as object);
                    api.PrivateParams = relations.Where(r => r.APIPathId == api.APIPathId && r.IO == "I").ToDictionary(r => r.Parameter.ParameterName, r => r.Parameter.ParameterDescription as object);
                    SetApiPathParameters(api);
                } catch(Exception e)
                {
                    CxLog.Error(_tag, _source, "There are duplicated relations to the same parameter name for the Api: " + api.URLPath, e);
                }
            }

            _apis = apiPaths.AsList();

            apit.Stop();

            CxLog.Debug(ApiEngine._tag, ApiEngine._source,
                "Build API Path Parameters took: " + apit.ElapsedMilliseconds.ToString() + " ms. : " + GlobalInfo.SystemName);

            //if (_assemblyResolver == null)
            //    _assemblyResolver = new ApiAssembliesResolver(_instance, _apis);

            ////if (_controllerResolver == null)
            ////    _controllerResolver = new ApiControllerResolver();

            //_config.Services.Replace(typeof(IAssembliesResolver), _assemblyResolver);
            //_config.Services.Replace(typeof(IHttpControllerTypeResolver), _controllerResolver);

            apit = Stopwatch.StartNew();
            SetupAssembliesResolver();

            apit.Stop();

            CxLog.Debug(ApiEngine._tag, ApiEngine._source,
                "Setup Assemblies Resolver took: " + apit.ElapsedMilliseconds.ToString() + " ms. : " + GlobalInfo.SystemName);
            //foreach (var api in apis)
            //{
            //    SetupApiPath(api);
            //}

            CxLog.Debug(_tag, _source, "API Engine initialized at: " + GlobalInfo.SystemName);
        }


        
        private void SetApiPathParameters(ApiPath api)
        {
            object value;

            if (api.PrivateParams.TryGetValue("authDisabled", out value))
            {
                bool isAuthDisabled;
                if (Boolean.TryParse((String)value, out isAuthDisabled))
                { 
                    api.isAuthDisabled = isAuthDisabled;
                }
            }

            value = null;
            if (api.PrivateParams.TryGetValue("filterIPDisabled", out value))
            {
                bool isIPFilterDisabled;
                if (Boolean.TryParse((String)value, out isIPFilterDisabled))
                {
                    api.isIPFilterDisabled = isIPFilterDisabled;
                }
            }
        }        

        private HttpMethod GetMethodByName(string name)
        {
            var property = typeof(HttpMethod).GetProperties().FirstOrDefault(p => p.Name.ToLower() == name.ToLower());
            if (property == null)
                return new HttpMethod(name.ToUpper()); // HttpMethod.Get;
            else
                return property.GetValue(null) as HttpMethod ?? HttpMethod.Get;
        }

        private void SetupApiPath(ApiPath api)
        {
            if (api != null)
            {
                var urlPath = api.URLPath;
                if (urlPath.Length > 1 && urlPath[0] == '/')
                    urlPath = urlPath.Substring(1);

                var name = api.ApiName;

                if (!_config.Routes.ContainsKey(name))
                {
                    var constraintsDic = new Dictionary<string, object>();

                    foreach (Match match in Regex.Matches(urlPath, @"{(.|\s)*?}"))
                    {
                        if (match.Value.Contains(':'))
                        {
                            var index = match.Value.IndexOf(':');
                            var key = match.Value.Substring(1, index - 1);
                            urlPath = urlPath.Replace(match.Value, "{" + key + "}");
                            var constraints = match.Value.Substring(index + 1, match.Value.Length - index - 2);
                            constraintsDic.Add(key, constraints);
                        }
                    }

                    var route = _config.Routes.MapHttpRoute(name, urlPath,
                    new { action = api.ClassMethod, apiObj = api },
                    new { httpMethod = new HttpMethodConstraint(GetMethodByName(api.HTTPMethod)) },
                    _routeHandler);

                    foreach (var kvp in constraintsDic) route.Constraints.Add(kvp);
                }
                else
                    throw new Exception("Duplicated API Path: " + name + ": " + GlobalInfo.SystemName);
            }
        }

        private void SetupControllers(List<ApiAssembly> loaded)
        {
            
            foreach (var asm in loaded)
            {
                foreach (var cont in asm.ApiControllers)
                {
                    if (cont.ClassType != null && cont.Descriptor == null)
                    {
                        cont.CreateControllerDescriptor(_config);
                    }
                    else
                    {
                        CxLog.Warn(_tag, _source, new Exception("Error at get class by name '" +cont.FQDName + "': " + GlobalInfo.SystemName));
                    }
                }
            }
        }

        private void AutoSelfHealing(Object stateInfo)
        {
            if (_recoveryCount > 0)
                CheckAssembliesResolver();

            _assemblyResolver.AutoRecovery();

            _recoveryCount++;
        }

        private void SetupAssembliesResolver(bool execute = false)
        {
            lock (_lock)
            {
                if (_assemblyResolver == null)
                {
                    _assemblyResolver = new ApiAssembliesResolver(_instance, _apis, _config);

                    _config.Services.Replace(typeof(IAssembliesResolver), _assemblyResolver);
                }

                if (execute)
                    _assemblyResolver.GetAssemblies();
            }
        }

        //private static ApiPath GetApiReferenceById(int apiPathId)
        //{
        //    var cnn = CxConnection.CreateDbConnectionByName(GlobalInfo.ConnectionName);
        //    var cmd = cnn.CreateCommand();
        //    cmd.CommandText = $"SELECT * FROM cnxadm.APIPathTbl WHERE ApiPathId = {apiPathId};SELECT * FROM APIPathParameterTbl WHERE ApiPathId = {apiPathId};SELECT * FROM APIParameterTbl";
        //    cnn.Open();

        //    IEnumerable<ApiPath> apis = null;
        //    IEnumerable<ApiParameterRel> relations = null;
        //    IEnumerable<ApiParameter> parameters = null;

        //    cmd.Execute(out apis)
        //        .Execute(out relations)
        //        .Execute(out parameters)
        //        .Close();

        //    cnn.Close();

        //    foreach (var relation in relations)
        //    {
        //        relation.Parameter = parameters.Where(p => p.APIParameterId == relation.APIParameterId).First();
        //    }

        //    foreach (var api in apis)
        //    {
        //        //api.References = relations.Where(r => r.APIPathId == api.APIPathId).ToArray();
        //        api.PublicParams = relations.Where(r => r.APIPathId == api.APIPathId && r.IO == "O").ToDictionary(r => r.Parameter.ParameterName, r => r.Parameter.ParameterDescription as object);
        //        api.PrivateParams = relations.Where(r => r.APIPathId == api.APIPathId && r.IO == "I").ToDictionary(r => r.Parameter.ParameterName, r => r.Parameter.ParameterDescription as object);
        //    }

        //    return apis.FirstOrDefault();
        //}

        //private static List<ApiPath> GetApiReferencesByAssembly(string sourcePath)
        //{
        //    var cnn = CxConnection.CreateDbConnectionByName(GlobalInfo.ConnectionName);

        //    var lookup = new Dictionary<int, ApiPath>();

        //    var query = @"SELECT P.*, PP.*, PT.* FROM cnxadm.ApiPathTbl P
        //                    INNER JOIN cnxadm.APIPathParameterTbl PP ON PP.APIPathId = P.APIPathId
        //                    INNER JOIN cnxadm.APIParameterTbl PT ON PT.APIParameterId = PP.APIParameterId
        //                    WHERE SourcePath = '" + sourcePath + "'";
        //    cnn.Open();

        //    var pathList = cnn.Query<ApiPath, ApiParameterRel, ApiParameter, ApiPath>(query,
        //        (a, rel, pt) =>
        //        {
        //            ApiPath path;

        //            if (!lookup.TryGetValue(a.APIPathId, out path))
        //            {
        //                lookup.Add(a.APIPathId, a);
        //                path = a;

        //                if (path.PrivateParams == null)
        //                    path.PrivateParams = new Dictionary<string, object>();

        //                if (path.PublicParams == null)
        //                    path.PublicParams = new Dictionary<string, object>();
        //            }

        //            if (rel.IO == "O")
        //            {
        //                path.PublicParams.Add(pt.ParameterName, pt.ParameterDescription);
        //            }
        //            else if (rel.IO == "I")
        //            {
        //                path.PrivateParams.Add(pt.ParameterName, pt.ParameterDescription);
        //            }

        //            return path;
        //        }, splitOn: "APIPathParameterId,APIParameterId").DefaultIfEmpty(null).Distinct().ToList();

        //    cnn.Close();

        //    return pathList;
        //}

        #endregion


        #region Public Methods

        internal void MapHttpRoutes()
        {
            foreach (var api in _apis)
            {
                SetupApiPath(api);
            }

            _config.Routes.MapHttpRoute("ResourceNotFound", "{*url}",
                new { url = RouteParameter.Optional },
                null,
                _routeHandler);
        }

        internal void SetupSelfHealing()
        {
            try
            {
                bool enabled = false;
                Boolean.TryParse(ConfigurationManager.AppSettings["SYSTEM_SELF_HEALING_ENABLED"], out enabled);
                _selfHealingEnabled = enabled;


                if (_selfHealingEnabled && _selfHealingTimer == null)
                {
                    long startAfter = 0;
                    long.TryParse(ConfigurationManager.AppSettings["SYSTEM_SELF_HEALING_START_AFTER"], out startAfter);
                    long interval = 0;
                    if (!long.TryParse(ConfigurationManager.AppSettings["SYSTEM_SELF_HEALING_INTERVAL"],
                        out interval)) interval = 180000;

                    _recoveryCount = 0;
                    _selfHealingTimer = new Timer(AutoSelfHealing, this, startAfter, interval);                    
                }
            }
            catch (Exception ex)
            {
                CxLog.Error(_tag, _source, "An error ocurred while setting up self healing configuration : " + GlobalInfo.SystemName, ex);
            }
        }

        internal void StopSelfHealing()
        {
            _selfHealingTimer?.Dispose();

            _selfHealingTimer = null;
        }

        internal List<ApiAssembly> GetCurrentAssemblies()
        {
            return _assemblies;
        }

        internal ConcurrentBag<Tuple<string, FileInfo, FileVersionInfo>> GetAssembliesFiles()
        {
            return _assembliesFiles;
        }

        internal void OnAssembliesLoaded(List<ApiAssembly> loaded)
        {
            if (loaded != null && loaded.Any())
            {
                if (_assemblies == null || !_assemblies.Any())
                {
                    _assemblies = loaded;                    
                }
                else
                {
                    _assemblies.AddRange(loaded);
                }

                //SetupControllers(loaded);
                var msg = "Assemblies Loaded: " + loaded.Count + ": " + GlobalInfo.SystemName;
                CxLog.Debug(_tag, _source, msg);                
            }
            else
            {
                CxLog.Warn(_tag, _source, new Exception("No Assemblies were Loaded at: " + GlobalInfo.SystemName));
            }

            //collectMemory();
        }

        internal ApiPath GetApiPathByRouteTemplate(string routeTemplate) //url obtained from request.GetRouteData().Route.RouteTemplate
        {
            if (routeTemplate.Length > 1 && routeTemplate[0] != '/')
                routeTemplate = "/" + routeTemplate;

            ApiPath api = _assemblies.SelectMany(a => {
                return a.ApiControllers.SelectMany(c =>
                {
                    return c.ApiPaths.Where(p =>
                                p.URLPath.Equals(routeTemplate, StringComparison.InvariantCultureIgnoreCase)
                           );
                });
            }).FirstOrDefault();

            return api;
        }

        internal bool SelfHealingFor(ApiPath api)
        {
            return SelfHealingFor(api.SourcePath);
        }

        internal bool SelfHealingFor(string sourcePath)
        {
            return _assemblyResolver.LoadAssembly(sourcePath);
        }

        internal bool WasAssembliesResolverExecuted()
        {
            return _assemblyResolver != null && _assemblyResolver.WasExecuted;
        }

        internal void CheckAssembliesResolver()
        {
            if (WasAssembliesResolverExecuted())
                return;

            SetupAssembliesResolver(true);

            if (!WasAssembliesResolverExecuted())
            {
                _apis.ForEach(p => p.Status = ApiPathStatus.Error);
                throw new ApplicationException("Assemblies Resolver was not executed : " + GlobalInfo.SystemName);
            }
        }

        //public static void collectMemory()
        //{
        //    System.Diagnostics.Debug.WriteLine("Memory used before collection: {0:N0}: " + GlobalInfo.SystemName, GC.GetTotalMemory(false));
        //    // Collect all generations of memory.
        //    //GC.Collect();
        //    //System.Diagnostics.Debug.WriteLine("Memory used after full collection: {0:N0}", GC.GetTotalMemory(true));
        //}

        //public void LoadNewAssembly(string sourcePath)
        //{
        //    List<ApiPath> paths = GetApiReferencesByAssembly(sourcePath);
        //    if (paths != null && paths.Any())
        //    {
        //        _instance._assemblyResolver.loadNewAssembly(sourcePath, paths);
        //        foreach (var api in paths)
        //            SetupApiPath(api);
        //    }
        //}

        //public ApiPath LoadApiPath(int apiPathId)
        //{
        //    ApiPath api = GetApiReferenceById(apiPathId);
        //    if (api != null)
        //        SetupApiPath(api);

        //    return api;
        //}

        //public void UnloadApiReference(int apiPathId)
        //{
        //    ApiPath api = GetApiReferenceById(apiPathId);
        //    if (api != null)
        //        UnloadApiReference(api);
        //}

        //public void UnloadApiReference(ApiPath api)
        //{
        //    var Name = api.ApiName;
        //    if (_config.Routes.ContainsKey(Name))
        //        _config.Routes.Remove(Name);
        //}

        //public void RefreshApiReference(ApiPath api)
        //{
        //    var Name = api.ApiName;
        //    if (_config.Routes.ContainsKey(Name))
        //    {
        //        _config.Routes.Remove(Name);
        //        api = GetApiReferenceById(api.APIPathId);
        //        if (api != null)
        //            SetupApiPath(api);
        //    }
        //}

        //public void RefreshApiReference(int apiPathId)
        //{
        //    ApiPath api = GetApiReferenceById(apiPathId);
        //    if (api != null)
        //        RefreshApiReference(api);
        //}

        #endregion
    }
}