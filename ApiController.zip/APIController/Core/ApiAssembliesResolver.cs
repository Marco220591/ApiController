﻿using APIController.Models.Core;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Http.Dispatcher;
using CxUtilities.Extensions;
using CxUtilities.Logger;
using System.Web.Http.Controllers;
using static APIController.Core.TypeActivator;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Http;
using Newtonsoft.Json;

namespace APIController.Core
{
    public class ApiAssembliesResolver : DefaultAssembliesResolver
    {
        private List<ApiPath> _apiPaths;
        private static ApiEngine _apiEngineRef;
        private static object _lock = new object();
        private static HttpConfiguration _config;
        private static object _lockRecovery = new object();

        public bool WasExecuted { get; private set; } = false;

        public ApiAssembliesResolver(ApiEngine apiEngine, List<ApiPath> apis, HttpConfiguration config)
        {
            _apiEngineRef = apiEngine;
            _apiPaths = apis;
            _config = config;
        }

        private string[] GetAssemblySources()
        {
            var w = Stopwatch.StartNew();

            var sources = _apiPaths.AsParallel().Select<ApiPath, string>(p => p.SourcePath).Distinct().ToList();

            w.Stop();
            CxLog.Debug(ApiEngine._tag, ApiEngine._source, "GetAssemblySources Sources Took: " + w.ElapsedMilliseconds.ToString() + " ms. : " + GlobalInfo.SystemName);

            w = Stopwatch.StartNew();
            var src =   (from f in _apiEngineRef.GetAssembliesFiles().AsParallel()
                        from s in sources.AsParallel()
                        where f.Item3.OriginalFilename != null && s.ToLower().Contains(f.Item3.OriginalFilename.ToLower())
                        select s).Distinct();

            w.Stop();
            CxLog.Debug(ApiEngine._tag, ApiEngine._source, "GetAssemblySources Join Took: " + w.ElapsedMilliseconds.ToString() + " ms. : " + GlobalInfo.SystemName);

            return src.ToArray();
        }

        //public ICollection<Assembly> GetAssemblies()
        //{
        //    //LoadAssembliesToSeparatedDomains();
        //    //return baseAssemblies;
        //    //ICollection<Assembly> baseAssemblies = base.GetAssemblies();            
        //    ICollection<Assembly> baseAssemblies = AppDomain.CurrentDomain.GetAssemblies().ToList();            
        //    //List<Assembly> assemblies = new List<Assembly>(baseAssemblies);
        //    IEnumerable<ApiPath> dist = _apiPaths.DistinctBy(p => p.SourcePath);
        //    List<ApiAssembly> apiAssemblies = new List<ApiAssembly>();

        //    foreach (var apiPath in dist)
        //    {

        //        string path = HttpContext.Current.Server.MapPath(GlobalInfo.AssemblyDirectory + apiPath.SourcePath);

        //        try
        //        {
        //            var asm = Assembly.LoadFrom(path);
        //            baseAssemblies.Add(asm);
        //            var apiAsm = new ApiAssembly(asm);
        //            List<ApiPath> paths = _apiPaths.Where(x => x.SourcePath.Equals(apiPath.SourcePath)).ToList();
        //            List<ApiAssemblyController> controllers = paths.DistinctBy(p => p.FQClassName).Select(c =>
        //            {
        //                Type apiClass = asm?.GetType(c.FQClassName);

        //                if (apiClass == null)
        //                {
        //                    CxLog.Warn(ApiEngine._tag, ApiEngine._source, new Exception($"Error at get class by name '{c.FQClassName}' on Assembly: '{apiPath.SourcePath}'"));
        //                }

        //                //Func<object, object> activator = ( o => Activator.CreateInstance((Type)o));                        
        //                ConstructorInfo ctor = apiClass.GetConstructors().First();
        //                ObjectActivator<IHttpController> createdActivator = TypeActivator.GetActivator<IHttpController>(ctor);

        //                return new ApiAssemblyController
        //                {
        //                    FQDName = c.FQClassName,
        //                    AssemblyRef = apiAsm,
        //                    ClassType = apiClass ,
        //                    Activator = createdActivator
        //                };
        //            }).ToList();                    

        //            foreach (var cont in controllers)
        //            {
        //                cont.SetApiPaths(paths.Where(x => x.FQClassName.Equals(cont.FQDName)).ToList());
        //            }
        //            apiAsm.ApiControllers = controllers;                    
        //            apiAssemblies.Add(apiAsm);
        //        }
        //        catch (Exception ex)
        //        {
        //            System.Diagnostics.Debug.Print(ex.Message);
        //        }
        //    }

        //    _apiEngineRef.onAssembliesLoaded(apiAssemblies);

        //    return baseAssemblies;
        //}

        public override ICollection<Assembly> GetAssemblies()
        {

            lock (_lock)
            {
                WasExecuted = true;

                CxLog.Debug(ApiEngine._tag, ApiEngine._source, "API Assemblies Resolver triggered - GetAssemblies(): " + GlobalInfo.SystemName);

                var watch = Stopwatch.StartNew();

                ICollection<Assembly> baseAssemblies = AppDomain.CurrentDomain.GetAssemblies().ToList();
                List<ApiAssembly> apiAssemblies = new List<ApiAssembly>();                

                List<ApiPath> sources = _apiPaths.AsParallel().DistinctBy(p => p.SourcePath).ToList(); //Get a disctinc of the different configured assemblies to be loaded

                //var sources = GetAssemblySources(); //Get a distinct available components on the service

                foreach (var src in sources)
                {
                    //Get the paths contained in the assembly                    
                    List<ApiPath> paths = _apiPaths.AsParallel().Where(x => x.SourcePath.Equals(src.SourcePath)).ToList();

                    try
                    {
                        //if (src.BusinessCapability != "secm") continue;
                         var apiAsm = LoadNewAssembly(src.SourcePath, paths);
                        if (apiAsm == null)
                        {
                            var msg = "Configured assembly not found: " + src.SourcePath + ": " + GlobalInfo.SystemName;
                            CxLog.Warn(ApiEngine._tag, ApiEngine._source, new Exception(msg));
                            paths.AsParallel().ForAll(p => p.Status = ApiPathStatus.NotExist);
                            continue;
                        }

                        baseAssemblies.Add(apiAsm.AssemblyRef);
                        apiAssemblies.Add(apiAsm);
                        
                    }
                    catch (Exception ex)
                    {
                        CxLog.Warn(ApiEngine._tag, ApiEngine._source, ex);
                        paths.AsParallel().ForAll(p => p.Status = ApiPathStatus.Error);
                    }
                }
                

                watch.Stop();
                CxLog.Debug(ApiEngine._tag, ApiEngine._source, "Assemblies were loaded in: " + watch.ElapsedMilliseconds.ToString() + " ms. : " + GlobalInfo.SystemName);

                watch = Stopwatch.StartNew();

                _apiEngineRef.OnAssembliesLoaded(apiAssemblies);

                watch.Stop();
                CxLog.Debug(ApiEngine._tag, ApiEngine._source, "On Assemblies Loaded Event took: " + watch.ElapsedMilliseconds.ToString() + " ms. : " + GlobalInfo.SystemName);

                return baseAssemblies;
            }
        }

        //public void loadNewAssembly(string sourcePath, ICollection<ApiPath> paths)
        //{
        //    ICollection<Assembly> baseAssemblies = AppDomain.CurrentDomain.GetAssemblies().ToList();
        //    List<ApiAssembly> apiAssemblies = new List<ApiAssembly>();

        //    try
        //    {
        //        var apiAsm = loadNewAssembly(sourcePath, paths, true);
        //        baseAssemblies.Add(apiAsm.AssemblyRef);
        //        _apiPaths.AddRange(paths);
        //        apiAssemblies.Add(apiAsm);
        //    }
        //    catch (Exception ex)
        //    {
        //        System.Diagnostics.Debug.Print(ex.Message);
        //    }

        //    _apiEngineRef.onAssembliesLoaded(apiAssemblies);
        //}

        private ApiAssembly LoadNewAssembly(string sourcePath, List<ApiPath> paths)
        {

            var ntime = Stopwatch.StartNew();

            ApiAssembly apiAsm;

            string path = System.Web.Hosting.HostingEnvironment.MapPath(GlobalInfo.AssemblyDirectory + sourcePath);

            try
            {
                if (!File.Exists(path))
                {
                    return null;
                }

                var asmTime = Stopwatch.StartNew();

                var asm = GetAssembly(path);

                asmTime.Stop();

                if (asmTime.ElapsedMilliseconds > GlobalInfo.MaxAsmLoadTime) { 
                    CxLog.Log(LogType.Warn, "Assembly loaded took more time than expected: " + sourcePath + " : " + GlobalInfo.SystemName, ApiEngine._tag, asmTime.ElapsedMilliseconds.ToString(), ApiEngine._source,null,null);
                }

                apiAsm = new ApiAssembly(asm);

                asmTime = Stopwatch.StartNew();

                //var classes = paths.AsParallel().DistinctBy(p => p.FQClassName).ToList();
                var classes = paths.AsParallel().Select(p => p.FQClassName).Distinct().ToList();

                List<ApiAssemblyController> controllers = classes.AsParallel().Select(cname =>
                {
                    var cctime = Stopwatch.StartNew();
                    Type apiClass = asm?.GetType(cname);
                    cctime.Stop();

                    if (cctime.ElapsedMilliseconds > GlobalInfo.MaxAsmLoadTime)
                    {
                        CxLog.Log(LogType.Warn, "Controller Class GetType: " + cname + " : " + sourcePath + ", took: " +
                                                cctime.ElapsedMilliseconds.ToString() + " ms. : " +
                                                GlobalInfo.SystemName, ApiEngine._tag,
                            cctime.ElapsedMilliseconds.ToString(), ApiEngine._source, null, null);
                    }

                    ObjectActivator<IHttpController> createdActivator = null;
                    ApiPathStatus status;

                    if (apiClass == null)
                    {
                        var msg = "Error at get class by name '" + cname + "' on Assembly: '" + sourcePath + "': " + GlobalInfo.SystemName;
                        CxLog.Warn(ApiEngine._tag, ApiEngine._source, new Exception(msg));
                        status = ApiPathStatus.NotLoaded;
                    }
                    else
                    {
                        //Func<object, object> activator = ( o => Activator.CreateInstance((Type)o));
                        ConstructorInfo ctor = apiClass
                            .GetConstructors(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)
                            .First();
                        createdActivator = GetActivator<IHttpController>(ctor);
                        status = ApiPathStatus.Loaded;
                    }

                    var cont = new ApiAssemblyController
                    {
                        FQDName = cname,
                        AssemblyRef = apiAsm,
                        ClassType = apiClass,
                        Activator = createdActivator
                    };

                    var apiPaths = paths.AsParallel().Where(x => x.FQClassName.Equals(cname)).ToList();

                    foreach (var apiPath in apiPaths)
                    {
                        apiPath.Status = status;
                        apiPath.ControllerRef = cont;
                    }

                    cont.SetApiPaths(apiPaths);
                    if (apiClass != null) cont.CreateControllerDescriptor(_config);

                    return cont;
                }).ToList();

                asmTime.Stop();

                if (asmTime.ElapsedMilliseconds > GlobalInfo.MaxAsmLoadTime)
                {
                    CxLog.Log(LogType.Warn, "API Assembly Controller for: " + sourcePath + ", took: " + asmTime.ElapsedMilliseconds.ToString() + " ms. : " +
                                            GlobalInfo.SystemName, ApiEngine._tag, asmTime.ElapsedMilliseconds.ToString(), ApiEngine._source, null, null);
                }
                
                //Load Assembly Dependencies                
                AssemblyName[] list = asm.GetReferencedAssemblies();
                
                var asmDep = Stopwatch.StartNew();
                
                //Parallel.ForEach(list, asmn =>
                foreach (var asmn in list)
                {
                    var depTime = Stopwatch.StartNew();

                    Assembly.Load(asmn.FullName);
                    //ResolveDependency(asmn.FullName, asm);
                    depTime.Stop();

                    //CxLog.Debug(ApiEngine._tag, ApiEngine._source,
                    //    "Assembly Dependency loaded in: " + depTime.ElapsedMilliseconds.ToString() + " ms. : " + sourcePath + " - Dep: " + asmn.FullName + " : " +
                    //    GlobalInfo.SystemName);

                    if (depTime.ElapsedMilliseconds > GlobalInfo.MaxAsmLoadTime)
                    {
                        CxLog.Log(LogType.Warn, "Assembly Dependency loaded took more time than expected: " +
                                                sourcePath + " - Dependency: " +
                                                asmn.FullName + " : " +
                                                GlobalInfo.SystemName, ApiEngine._tag,
                            depTime.ElapsedMilliseconds.ToString(), ApiEngine._source, null, null);
                    }
                }
                asmDep.Stop();                

                //CxLog.Debug(ApiEngine._tag, ApiEngine._source,
                //    "Assembly Dependencies loaded in total: " + asmDep.ElapsedMilliseconds.ToString() + " ms. : " + sourcePath + " : " +
                //    GlobalInfo.SystemName);

                if (asmDep.ElapsedMilliseconds > GlobalInfo.MaxAsmLoadTime)
                {
                    CxLog.Log(LogType.Warn, "Assembly Dependencies loaded took more time than expected: " + sourcePath + " : " +
                                             GlobalInfo.SystemName, ApiEngine._tag,
                        asmDep.ElapsedMilliseconds.ToString(), ApiEngine._source, null, null);
                }
                

                //asmTime = Stopwatch.StartNew();

                //foreach (var cont in controllers)
                //{
                //    cont.SetApiPaths(paths.AsParallel().Where(x => x.FQClassName.Equals(cont.FQDName)).ToList()); 
                //}

                //asmTime.Stop();

                //if (asmTime.ElapsedMilliseconds > GlobalInfo.MaxAsmLoadTime)
                //{
                //    CxLog.Log(LogType.Warn, "API Assembly Controller SetApiPaths for: " + sourcePath + ", took: " + asmTime.ElapsedMilliseconds.ToString() + " ms. : " +
                //                            GlobalInfo.SystemName, ApiEngine._tag, asmTime.ElapsedMilliseconds.ToString(), ApiEngine._source, null, null);
                //}

                apiAsm.ApiControllers = controllers;


            }
            catch (Exception ex)
            {
                var errorMsg = "Error loading the Dll: '" + sourcePath + "': " + GlobalInfo.SystemName;
                var nex = new Exception(errorMsg +":\r\n\r\n", ex);
                CxLog.Warn(ApiEngine._tag, ApiEngine._source, nex);
                throw nex;
            }

            ntime.Stop();

            if (ntime.ElapsedMilliseconds > GlobalInfo.MaxAsmLoadTime)
            {
                CxLog.Log(LogType.Warn, "LoadNewAssembly took more time than expected for: " + sourcePath + ", took: " + ntime.ElapsedMilliseconds.ToString() + " ms. : " +
                                        GlobalInfo.SystemName, ApiEngine._tag, ntime.ElapsedMilliseconds.ToString(), ApiEngine._source, null, null);
            }

            return apiAsm;
        }

        //private Assembly GetAssembly(string path)
        //{            
        //    FileStream file = null;
        //    Assembly asm = null;
        //    try
        //    {
        //        file = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        //        if (file.CanRead)
        //        {
        //            asm = Assembly.LoadFrom(path);
        //        }
        //        else
        //        {
        //            throw new FileLoadException("Assembly cannot be loaded/readed");
        //        }
        //    }
        //    finally
        //    {
        //        file?.Close();
        //    }

        //    return asm;
        //}

        private static Assembly GetAssembly(string path)
        {
            FileStream file = null;
            Assembly asm = null;

            using (file = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                if (file.CanRead)
                {
                    asm = Assembly.LoadFrom(path);
                }
                else
                {
                    throw new FileLoadException("Assembly cannot be loaded/readed");
                }
            }            

            return asm;
        }

        public bool LoadAssembly(string sourcePath)
        {
            lock (_lock)
            {
                var watch = Stopwatch.StartNew();

                ICollection<Assembly> baseAssemblies = AppDomain.CurrentDomain.GetAssemblies().ToList();
                List<ApiAssembly> apiAssemblies = new List<ApiAssembly>();

                //Get the paths contained in the assembly
                List<ApiPath> paths = _apiPaths.Where(x => x.SourcePath.Equals(sourcePath, StringComparison.InvariantCultureIgnoreCase)).ToList();

                try
                {
                    var apiAsm = LoadNewAssembly(sourcePath, paths);
                    if (apiAsm == null)
                    {
                        var msg = "Configured assembly not found: " + sourcePath + ": " + GlobalInfo.SystemName;
                        CxLog.Warn(ApiEngine._tag, ApiEngine._source, new Exception(msg));
                        paths.ForEach(p => p.Status = ApiPathStatus.NotExist);
                        return false;
                    }

                    baseAssemblies.Add(apiAsm.AssemblyRef);
                    apiAssemblies.Add(apiAsm);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    paths.ForEach(p => p.Status = ApiPathStatus.Error);
                    return false;
                }

                _apiEngineRef.OnAssembliesLoaded(apiAssemblies);

                watch.Stop();
                CxLog.Debug(ApiEngine._tag, ApiEngine._source, "Assembly was loaded in: " + watch.ElapsedMilliseconds.ToString() + " ms. : " + sourcePath + " : "  + GlobalInfo.SystemName);

                return true;

            }
        }

        #region AssemblyResolve

        public static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            try
            {
                Exception ex = (Exception)e.ExceptionObject;
                var msg = "Unhandled Exception Ocurred, IsTerminating: " + e.IsTerminating + ", Args:" + JsonConvert.SerializeObject(e) + ", " + JsonConvert.SerializeObject(sender) + " : " + GlobalInfo.SystemName;
                CxLog.Error(ApiEngine._tag, ApiEngine._source, msg, ex);
            }
            catch (Exception ex)
            {
                var msg = "Unhandled Exception Ocurred, error while getting the exeption: " +
                          JsonConvert.SerializeObject(e) + ", " + JsonConvert.SerializeObject(sender) + " : " + GlobalInfo.SystemName;
                CxLog.Error(ApiEngine._tag, ApiEngine._source, msg, ex);
            }
        }

        public static Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            var vStr = "Version=";
            var vIdx = args.Name.IndexOf(vStr, StringComparison.Ordinal) + vStr.Length;
            var name = args.Name.Substring(0, args.Name.IndexOf(','));
            var version = args.Name.Substring(vIdx, args.Name.IndexOf(',', vIdx) - vIdx).Trim().Split('.').Select(t => int.Parse(t)).ToArray();

            //var asmTime = Stopwatch.StartNew();

            var assembly = AppDomain.CurrentDomain.GetAssemblies().AsParallel().FirstOrDefault(a => a.FullName == args.Name);

            //asmTime.Stop();

            //CxLog.Log(LogType.Warn, "Search Assembly in Current Domain: " + asmTime.ElapsedMilliseconds.ToString() + " ms. : <" + args.Name + "> " +
            //                            GlobalInfo.SystemName, Core.ApiEngine._tag,
            //        asmTime.ElapsedMilliseconds.ToString(), Core.ApiEngine._source, null, null);            

            if (assembly != null)
                return assembly;

            try
            {
                assembly = FindAssembly(name, version, args.Name, args.RequestingAssembly);
            }
            catch (Exception ex)
            {
                var aex = new ApplicationException(args.RequestingAssembly?.FullName + " --> " + args.Name + " : " + GlobalInfo.SystemName, ex);
                CxLog.Warn(ApiEngine._tag, ApiEngine._source, aex);
            }

            return assembly;
        }

        private static void ResolveDependency(string assemblyName, Assembly requestingAssembly)
        {
            CurrentDomain_AssemblyResolve(null, new ResolveEventArgs(assemblyName, requestingAssembly));
        }

        private static Assembly FindAssembly(string name, int[] version, string fullName, Assembly reference = null)
        {
            var original = name + ".dll";

            var files = (from f in _apiEngineRef.GetAssembliesFiles().AsParallel()
                where f.Item3.OriginalFilename != null &&
                      f.Item3.OriginalFilename.Equals(original, StringComparison.OrdinalIgnoreCase)
                select f).ToList();

            var v = new Version(version[0], version[1], version[2], version[3]);
            ConcurrentBag<Assembly> assembliesExact = new ConcurrentBag<Assembly>();
            ConcurrentBag<Assembly> assemblies = new ConcurrentBag<Assembly>();

            Parallel.ForEach(files, file =>
            {
                try
                {
                    var assembly = GetAssembly(file.Item2.FullName);
                    
                    if (assembly.FullName == fullName)
                    {
                        assembliesExact.Add(assembly);
                    }
                    else 
                    {
                        var eq = true;
                        var pversioneq = CompareVersion(version, file.Item3.ProductVersion);
                        var fversioneq = CompareVersion(version, file.Item3.FileVersion);
                        var veq = assembly.GetName().Version.CompareTo(v) == 0;

                        eq = veq || pversioneq || fversioneq;

                        if (eq)
                            assemblies.Add(assembly);
                    }

                }
                catch (Exception ex)
                {
                    var nex = new FileLoadException("Failed to load dependency for: " + original + " -- " + file.Item2.FullName + " -- " + file.Item3.OriginalFilename + " -- " + file.Item3.ProductVersion, ex);                    
                    CxLog.Warn(ApiEngine._tag, ApiEngine._source, "Requesting Assembly: " + reference?.FullName + " : " + GlobalInfo.SystemName, nex);
                }
            });

            var exactMatches = false;
            var possibleMatches = false;

            if (assembliesExact.Count == 0)
            {
                CxLog.Warn(ApiEngine._tag, ApiEngine._source,
                    "Requested Assembly has no extact matches: " + fullName + " : " + GlobalInfo.SystemName, null);

                if (assemblies.Count == 0)
                {
                    CxLog.Warn(ApiEngine._tag, ApiEngine._source,
                        "Requested Assembly has no possible matches: " + fullName + " : " + GlobalInfo.SystemName, null);
                }
            }
            else if (assembliesExact.Count > 0)
            {
                CxLog.Warn(ApiEngine._tag, ApiEngine._source,
                    "Requested Assembly has exact matches: " + assembliesExact.Count + " : " + fullName + " : " + GlobalInfo.SystemName, null);
                exactMatches = true;
            }

            if (assemblies.Count > 0)
            {
                CxLog.Warn(ApiEngine._tag, ApiEngine._source,
                    "Requested Assembly has possible matches: " + assemblies.Count + " : " + fullName + " : " + GlobalInfo.SystemName, null);

                possibleMatches = true;
            }

            if (exactMatches)
                return assembliesExact.First();
            else if (possibleMatches)
                return assemblies.First();


            return null;
        }

        private static bool CompareVersion(int[] source, string target)
        {
            var eq = true;

            var version = target.Trim().Split('.').Select(t =>
            {
                var r = Regex.Match(t, "(\\d)*").Value;
                int s = 0;
                int.TryParse(string.IsNullOrEmpty(r) ? "0" : r, out s);
                return s;
            }).ToArray();

            if (version.Length == 0)
                return false;

            for (int idx = 0; idx < 5; idx++)
            {
                if ((idx < version.Length ? version[idx] : 0) != (idx < source.Length ? source[idx] : 0))
                {
                    eq = false;
                    break;
                }
            }

            return eq;
        }

        #endregion

        public void AutoRecovery()
        {
            lock (_lock)
            {
                var components = _apiPaths.Where(p => p.Status == ApiPathStatus.Error).Select(p => p.SourcePath)
                    .Distinct().ToList();

                foreach (var comp in components)
                {
                    LoadAssembly(comp);
                }

                //if (components.Count == 0)
                //    _apiEngineRef.StopSelfHealing();
            }
        }

        //public void LoadAssembliesToSeparatedDomains()
        //{

        //    IEnumerable<ApiPath> dist = _apiPaths.DistinctBy(p => p.SourcePath);
        //    List<ApiAssembly> apiAssemblies = new List<ApiAssembly>();
        //    List<AppDomain> domains = new List<AppDomain>();

        //    foreach (var apiPath in dist)
        //    {

        //        string path = HttpContext.Current.Server.MapPath(GlobalInfo.AssemblyDirectory + apiPath.SourcePath);

        //        try
        //        {
        //            var domaininfo = new AppDomainSetup()
        //            {
        //                ApplicationBase = AppDomain.CurrentDomain.SetupInformation.ApplicationBase,
        //                ConfigurationFile = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile,
        //                LoaderOptimization = LoaderOptimization.MultiDomainHost,
        //                PrivateBinPath = "Assemblies\\Local\\v1;Assemblies\\Local\\v2;bin"
        //            };
        //            var newAppDomain = AppDomain.CreateDomain(apiPath.SourcePath, AppDomain.CurrentDomain.Evidence, domaininfo);

        //            var asm = newAppDomain.Load(AssemblyName.GetAssemblyName(path).Name);                    
        //            //var asm = Assembly.LoadFrom(path);

        //            var apiAsm = new ApiAssembly(asm, newAppDomain);
        //            List<ApiPath> paths = _apiPaths.Where(x => x.SourcePath.Equals(apiPath.SourcePath)).ToList();
        //            List<ApiAssemblyController> controllers = paths.DistinctBy(p => p.FQClassName).Select(c =>
        //            {
        //                Type apiClass = asm?.GetType(c.FQClassName);

        //                if (apiClass == null)
        //                {
        //                    CxLog.Warn(ApiEngine._tag, ApiEngine._source, new Exception($"Error at get class by name '{c.FQClassName}' on Assembly: '{apiPath.SourcePath}'"));
        //                }

        //                //Func<object, object> activator = ( o => Activator.CreateInstance((Type)o));                        
        //                ConstructorInfo ctor = apiClass.GetConstructors().First();
        //                ObjectActivator<IHttpController> createdActivator = TypeActivator.GetActivator<IHttpController>(ctor);

        //                return new ApiAssemblyController
        //                {
        //                    FQDName = c.FQClassName,
        //                    AssemblyRef = apiAsm,
        //                    ClassType = apiClass,
        //                    Activator = createdActivator
        //                };
        //            }).ToList();

        //            foreach (var cont in controllers)
        //            {
        //                cont.SetApiPaths(paths.Where(x => x.FQClassName.Equals(cont.FQDName)).ToList());
        //            }
        //            apiAsm.ApiControllers = controllers;
        //            apiAssemblies.Add(apiAsm);
        //        }
        //        catch (Exception ex)
        //        {
        //            var errorMsg = $"Error loading the Dll '{apiPath.SourcePath}'";
        //            //ex = new Exception($"{errorMsg}:\r\n\r\n{ex.Message}",ex.InnerException);                    
        //            //CxLog.Warn(ApiEngine._tag, ApiEngine._source, ex);

        //            System.Diagnostics.Debug.Print(errorMsg);
        //        }
        //    }

        //    _apiEngineRef.onAssembliesLoaded(apiAssemblies);

        //}
    }
}