﻿//using CxUtilities.Web.Http;
//using System;
//using System.Collections.Generic;
//using System.Diagnostics.CodeAnalysis;
//using System.Linq;
//using System.Reflection;
//using System.Web;
//using System.Web.Http.Controllers;
//using System.Web.Http.Dispatcher;

//namespace APIController.Core
//{
//    public class ApiControllerResolver : DefaultHttpControllerTypeResolver
//    {
//        public ApiControllerResolver() : base(IsHttpEndpoint) 
//        {

//        }    

//        internal static bool IsHttpEndpoint(Type t)
//        {
//            if (t == null) throw new ArgumentNullException("t");

//            var name = t.FullName;

//            return
//             t != null &&
//             t.IsClass &&
//             t.IsVisible &&
//             !t.IsAbstract &&
//             (typeof(IHttpController).IsAssignableFrom(t));
//        }
//    }
//}