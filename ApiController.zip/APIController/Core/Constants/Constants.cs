﻿namespace APIController.Core.Constants
{
    public static class ReasonMessage
    {

        public struct InvalidCredentials
        {
            public const string Code = "2131";
            public const string Description = "Invalid Credentials";
            public const string HttpCode = HttpCodes.Unauthorized;
        }

        public struct CredentialsRequired
        {
            public const string Code = "2133";
            public const string Description = "Credentials are needed to be provided";
            public const string HttpCode = HttpCodes.Unauthorized;
        }

        public struct ClientNotAllowed
        {
            public const string Code = "2130";
            public const string Description = "Client is not allowed";
            public const string HttpCode = HttpCodes.Forbidden;
        }

        public struct NotImplemented
        {
            public const string Code = "2133";
            public const string Description = "The requested resource or operation is not implemented";
            public const string HttpCode = HttpCodes.NotImplemented;
        }

        public struct NotFound
        {
            public const string Code = "2132";
            public const string Description = "The requested resource was not found or it is not available";
            public const string HttpCode = HttpCodes.NotFound;
        }
    }

    public static class HttpCodes
    {
        public const string Unauthorized = "401";
        public const string Forbidden = "403";
        public const string NotFound = "404";
        public const string NotImplemented = "501";
    }
    
}