﻿//using APIController.Models.Core;
//using System;
//using System.Reflection;
//using Newtonsoft.Json.Linq;
//using System.Net.Http;
//using System.Configuration;
//using System.Web.Http;
//using APIController.Handlers;
//using CxUtilities.DataConection;
//using Dapper;
//using System.Web;
//using System.Web.Http.Routing;
//using System.Linq;
//using System.Collections.Generic;
//using CxUtilities.Extensions;
//using System.Text.RegularExpressions;
//using CxUtilities.Logger;

//namespace APIController.Core
//{
//    public class ApiProcess
//    {
//        #region Properties

//        private readonly ApiReference _apiReference; 
//        private readonly HttpRequestMessage _request;
//        private string _postData;
//        #endregion

//        #region Constructor

//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="apiReference"></param>
//        public ApiProcess(ApiReference apiReference)
//        {
//            _apiReference = apiReference;
//            _request = null;
//        }
//        #endregion

//        #region Public Methods
//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="apiReference"></param>
//        /// <param name="postData"></param>
//        /// <param name="request"></param>
//        public ApiProcess(ApiReference apiReference, string postData, HttpRequestMessage request)
//        {
//            _apiReference = apiReference;
//            _postData = postData;
//            _request = request;
//        }

//        /// <summary>
//        /// 
//        /// </summary>
//        /// <returns></returns>
//        public object Invoke()
//        {
//            return _apiReference.CommandType == Utils.Const.CommandType.Assembly ? InvokeAssembly() : "";
//        }

//        /// <summary>
//        /// Regresa un valor de una cadena JSon sin importar si es JArray o JObject
//        /// </summary>
//        /// <param name="jasonString"></param>
//        /// <param name="returnValue"></param>
//        /// <returns></returns>
//        public string JSonValue(string jasonString, string returnValue)
//        {
//            try
//            {
//                var token = JToken.Parse(jasonString);

//                if (token is JArray)
//                {
//                    var aO = JArray.Parse(jasonString);
//                    return (string)aO.SelectToken(returnValue);
//                }

//                if (token is JObject)
//                {
//                    var o = JObject.Parse(jasonString);
//                    return (string)o.SelectToken(returnValue);
//                }
//            }
//            catch
//            {
//                return "";
//            }

//            return "";
//        }

//        /// <summary>
//        /// 
//        /// </summary>
//        /// <returns></returns>
//        private object InvokeAssembly()
//        {
//            var assemblyPath = _apiReference.SourcePath;
//            //var assemblyType = $"{_apiReference.SourceFQDN}.{_apiReference.FQClassName}";
//            var assemblyType = _apiReference.FQClassName;
//            var methodName = _apiReference.ClassMethod;
//            var parameters = new object[4];
//            parameters[0] = _apiReference.ConnectionString;
//            parameters[1] = _request;
//            parameters[2] = ConfigurationManager.AppSettings;
//            parameters[3] = ConfigurationManager.ConnectionStrings;

//            var assembly = Assembly.LoadFrom(assemblyPath);
//            var type = assembly.GetType(assemblyType);
//            var method = type.GetMethod(methodName);
//            /*ParameterInfo[] pInfo = method.GetParameters();
//            if (pInfo.Length > 0)
//            {
//                List<object> pList = new List<object>();
//                foreach (var pI in pInfo)
//                {
//                    var x = _request.GetRouteData();
//                    var y = _request.GetQueryNameValuePairs();
//                    var z = _request.();

//                    //Localizar el valor del parámetro en cadena JSON
//                    string sValor = JSonValue(_postData, pI.Name);
//                    pList.Add(sValor);
//                }
//                parameters = pList.ToArray();
//            }
//            */
//            var obj = Activator.CreateInstance(type);
//            //Execute the method.
//            var result = method.Invoke(obj, parameters);
//            return result;
//        }

//        #endregion

//        #region private static

//        internal static string GetApiName(ApiReference api)
//        {
//            return api.APIPathId+":"+api.FQClassName+"."+api.ClassMethod;
//        }

//        //private static PathApiData GetApiData(ApiReference api)
//        //{
//        //    Assembly apiAssembly;
//        //    try
//        //    {
//        //        apiAssembly = Assembly.LoadFile(GetPath(api.SourcePath));
//        //    }
//        //    catch (Exception) { return null; }

//        //    var apiClass = apiAssembly.GetType(api.FQClassName);
//        //    if (apiClass == null)
//        //        return null;

//        //    var apiMethod = apiClass.GetMethod(api.ClassMethod);

//        //    return apiMethod != null ? new PathApiData(api) : null;
//        //}

//        private static HttpMethod GetMethodByName(string name)
//        {
//            var property = typeof(HttpMethod).GetProperties().FirstOrDefault(p => p.Name.ToLower() == name.ToLower());
//            if (property == null)
//                return new HttpMethod(name.ToUpper()); // HttpMethod.Get;
//            else
//                return property.GetValue(null) as HttpMethod ?? HttpMethod.Get;
//        }

//        private static string GetPath(string path)
//        {
//            return HttpContext.Current.Server.MapPath(GlobalInfo.AssemblyDirectory + path);
//        }
//        #endregion

//        #region public static

//        internal static ApiReference GetApiReferenceById(int apiPathId)
//        {
//            var cnn = CxConnection.CreateDbConnectionByName(GlobalInfo.ConnectionName);
//            var cmd = cnn.CreateCommand();
//            cmd.CommandText = "SELECT * FROM cnxadm.APIPathTbl WHERE ApiPathId = "+ apiPathId +";SELECT * FROM APIPathParameterTbl WHERE ApiPathId = "+apiPathId+";SELECT * FROM APIParameterTbl";
//            cnn.Open();

//            IEnumerable<ApiReference> apis = null;
//            IEnumerable<ApiParameterRel> relations = null;
//            IEnumerable<ApiParameter> parameters = null;

//            cmd.Execute(out apis)
//                .Execute(out relations)
//                .Execute(out parameters)
//                .Close();

//            cnn.Close();

//            foreach (var relation in relations)
//            {
//                relation.Parameter = parameters.Where(p => p.APIParameterId == relation.APIParameterId).First();
//            }

//            foreach (var api in apis)
//            {
//                api.References = relations.Where(r => r.APIPathId == api.APIPathId).ToArray();
//            }

//            return apis.FirstOrDefault();
//        }

//        public static void InitializeAssemblies(HttpConfiguration config)
//        {
//            int MessageId = 0;
//            CxLog.Log("Initialize Assemblies Start", ApiRequestHandler._ApiControllerTag, WebApiConfig._WebApiConfigKey, ApiRequestHandler._ApiControllerSource, (++MessageId).ToString());
//            /**/
//            var cnn = CxConnection.CreateDbConnectionByName(GlobalInfo.ConnectionName);
//            var cmd = cnn.CreateCommand();
//            cmd.CommandText = "SELECT * FROM cnxadm.APIPathTbl;SELECT * FROM APIPathParameterTbl;SELECT * FROM APIParameterTbl";
//            cnn.Open();

//            IEnumerable<ApiReference> apis = null;
//            IEnumerable<ApiParameterRel> relations = null;
//            IEnumerable<ApiParameter> parameters = null;

//            cmd.Execute(out apis)
//                .Execute(out relations)
//                .Execute(out parameters)
//                .Close();

//            cnn.Close();

//            foreach (var relation in relations)
//            {
//                relation.Parameter = parameters.Where(p => p.APIParameterId == relation.APIParameterId).First();
//            }

//            foreach (var api in apis)
//            {
//                api.References = relations.Where(r => r.APIPathId == api.APIPathId).ToArray();
//            }

//            //const string query = @"SELECT API.* FROM cnxadm.APIPathTbl API;";
//            //var apis = cnn.Query<ApiReference>(query);
//            /**/
//            foreach (var api in apis)
//            {
//                LoadApiReference(config, api);
//            }
//            CxLog.Log("Initialize Assemblies End", ApiRequestHandler._ApiControllerTag, WebApiConfig._WebApiConfigKey, ApiRequestHandler._ApiControllerSource, (++MessageId).ToString());
//        }

//        public static void LoadApiReference(HttpConfiguration config, int apiPathId)
//        {
//            ApiReference api = GetApiReferenceById(apiPathId);
//            if (api != null)
//                LoadApiReference(config, GetApiReferenceById(apiPathId));
//        }

//        public static void LoadApiReference(HttpConfiguration config, ApiReference api)
//        {
//            PathApiData apiData = new PathApiData(api); // GetApiData(api);
//            if (apiData != null)
//            {
//                var urlPath = api.URLPath;
//                if (urlPath.Length > 1 && urlPath[0] == '/')
//                    urlPath = urlPath.Substring(1);
//                var Name = GetApiName(api);
//                if (!config.Routes.ContainsKey(Name))
//                {
//                    var route = config.Routes.MapHttpRoute(Name, urlPath,
//                    new { action = apiData.Api.ClassMethod },
//                    new { httpMethod = new HttpMethodConstraint(GetMethodByName(api.HTTPMethod)) },
//                    new ApiRequestHandler(apiData));

//                    foreach (Match match in Regex.Matches(urlPath, @"{(.|\s)*?}"))
//                    {
//                        if (match.Value.Contains(':'))
//                        {
//                            var index = match.Value.IndexOf(':');
//                            var key = match.Value.Substring(1, index - 1);
//                            var constraints = match.Value.Substring(index + 1, match.Value.Length - index - 2);
//                            route.Constraints.Add(key, constraints);
//                        }
//                    }
//                }
//                else
//                    throw new Exception("??????");
//            }
//        }

//        public static void UnloadApiReference(HttpConfiguration config, int apiPathId)
//        {
//            ApiReference api = GetApiReferenceById(apiPathId);
//            var route = config.Routes.FirstOrDefault(r => (api = (r.Handler as ApiRequestHandler)?.ApiData?.Api)?.APIPathId.Equals(apiPathId) == true);
//            if (route != null)
//                config.Routes.Remove(GetApiName(api));
//        }

//        public static void UnloadApiReference(HttpConfiguration config, ApiReference api)
//        {
//            var Name = GetApiName(api);
//            if (config.Routes.ContainsKey(Name))
//                config.Routes.Remove(Name);
//        }

//        public static void RefreshApiReference(HttpConfiguration config, ApiReference api)
//        {
//            var Name = GetApiName(api);
//            config.Routes.Remove(Name);
//            api = GetApiReferenceById(api.APIPathId);
//            if (api != null)
//                LoadApiReference(config, api);
//        }

//        public static void RefreshApiReference(HttpConfiguration config, int apiPathId)
//        {
//            ApiReference api = GetApiReferenceById(apiPathId);
//            var route = config.Routes.FirstOrDefault(r => (api = (r.Handler as ApiRequestHandler)?.ApiData?.Api)?.APIPathId.Equals(apiPathId) == true);
//            if (route != null)
//                config.Routes.Remove(GetApiName(api));
//            api = GetApiReferenceById(apiPathId);
//            if (api != null)
//                LoadApiReference(config, GetApiReferenceById(apiPathId));
//        }

//        #endregion
//    }
//}