﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Http;
using Newtonsoft.Json;
using System.Configuration;
using System.IO;
using CxUtilities.Exceptions;
using CxUtilities.Network;
using System.Net;
using APIController.Handlers;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Web.Http.Tracing;
using APIController.Utils;
using CxUtilities.Logger;

namespace APIController
{
    public class WebApiApplication : HttpApplication
    {
        //private string _systemSource = null;
        private GlobalInfo _globalInfo;
    
        protected void Application_Start()
        {
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            System.Net.ServicePointManager.DefaultConnectionLimit = int.MaxValue;

            _globalInfo = new GlobalInfo();

            int currentMinWorker, currentMinIOC, currentMaxWorker, currentMaxIOC;
            // Get the current settings.
            ThreadPool.GetMinThreads(out currentMinWorker, out currentMinIOC);
            ThreadPool.GetMaxThreads(out currentMaxWorker, out currentMaxIOC);            

            CxLog.Debug(Core.ApiEngine._tag, Core.ApiEngine._source, "Application_Start: " + GlobalInfo.SystemName 
                + " : Current ThreadPool Values: MinIOCP = " + currentMinIOC + ", MinWorker = " + currentMinWorker + ", MaxIOC = " 
                + currentMaxIOC + ", MaxWorker = " + currentMaxWorker);

            int workerThreads = string.IsNullOrEmpty(ConfigurationManager.AppSettings["MIN_WORKER_THREADS"])
                ? currentMinWorker
                : Convert.ToInt32(ConfigurationManager.AppSettings["MIN_WORKER_THREADS"]);

            int iocpThreads = string.IsNullOrEmpty(ConfigurationManager.AppSettings["MIN_IOCP_THREADS"])
                ? currentMinWorker
                : Convert.ToInt32(ConfigurationManager.AppSettings["MIN_IOCP_THREADS"]);

            // Change the minimum number of worker threads and minimum asynchronous I/O completion threads.
            if (ThreadPool.SetMinThreads(workerThreads, iocpThreads))
            {
                CxLog.Debug(Core.ApiEngine._tag, Core.ApiEngine._source,
                    "Application_Start: " + GlobalInfo.SystemName +
                    " : Minimum configuration value set MinIOCP = " + iocpThreads + " and MinWorker = " +
                    workerThreads);
            }
            else
            {
                // The minimum number of threads was not changed.
                CxLog.Debug(Core.ApiEngine._tag, Core.ApiEngine._source, "Application_Start: " + GlobalInfo.SystemName 
                    + ", The minimum number of threads was not changed to: " 
                    + "MinIOCP = " + iocpThreads + " and MinWorker = " + workerThreads);
            }            
           
            GlobalConfiguration.Configure(WebApiConfig.Register);
            GlobalConfiguration.Configuration.EnsureInitialized();
            //GlobalConfiguration.Configure(Core.ApiProcess.InitializeAssemblies);            

            //GlobalConfiguration.Configuration.Formatters.JsonFormatter.SerializerSettings.Converters.Add(new DateTimeConverter() { DateTimeFormat = "yyyy-MM-ddTHH:mm:ss" });
            //CultureInfo culture = (CultureInfo)CultureInfo.CurrentCulture.Clone();
            //culture.DateTimeFormat.ShortDatePattern = "yyyy-MM-dd";
            //culture.DateTimeFormat.LongTimePattern = "yyyy-MM-ddTHH:mm:ss";
            ////culture.DateTimeFormat.FullDateTimePattern = "yyyy-MMM-ddTHH:mm:ss";
            //Thread.CurrentThread.CurrentCulture = culture;

            //var json = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            //json.SerializerSettings.Culture = culture;
            //json.SerializerSettings.DateFormatString = "yyyy-MM-ddTHH:mm:ss";
        }

        protected void Application_Error(object sender, EventArgs e)
        {            
            var exc = Server.GetLastError();

            if (exc.GetType() == typeof(HttpException))
            {
                ExceptionHandler.ManageGlobalException(new DataServiceException(exc.Message, exc), Response);
            }
            else
            {
                ExceptionHandler.ManageGlobalException(new ApplicationException(exc.Message, exc), Response);
            }

            Server.ClearError();
        }
    }

    public class DateTimeConverter : JsonConverter
    {

        /// <summary> 
        /// holds ISO format to be used. 
        /// </summary> 
        public string DateTimeFormat { get; set; }

        /// <summary> 
        /// Sets the custom ISO format  
        /// </summary> 
        public DateTimeConverter()
        {
            DateTimeFormat = "yyyy-MM-ddTHH:mm:ss";
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            if (!(value is DateTime)) return;
            var dt = (DateTime)value;
            writer.WriteRawValue(dt.ToString(DateTimeFormat));
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            return null;
        }

        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(DateTime);
        }
    }

    public class GlobalInfo
    {        
        public static string ConnectionName { get; } = "DB_CNXMA";
        public static string AssemblyDirectory { get; } = "~/Assemblies";
        public static string DependenciesDirectory { get; } = "~/bin/Dependencies";
        public static long MaxAsmLoadTime { get; } = 300; //Maximun Assembly load time in milliseconds to trigger a warning to the logs
        public static string SystemName { get; private set; }
        public static TraceLevel SystemTraceLevel { get; private set; }
        public static bool SystemTraceIsVerbose { get; private set; }

        public GlobalInfo()
        {            
            HttpContext.Current.Application["system_user_db"] = new GenericFunc().GetSystemUser();
            SystemName = String.IsNullOrEmpty(ConfigurationManager.AppSettings["SYSTEM_NAME"]) ? Environment.MachineName : ConfigurationManager.AppSettings["SYSTEM_NAME"] + ":" + Environment.MachineName;

            try
            {
                string traceLevel = ConfigurationManager.AppSettings["SYSTEM_DIAGNOSTICS_TRACE_LEVEL"];
                SystemTraceLevel = (TraceLevel)Enum.Parse(typeof(TraceLevel), string.IsNullOrEmpty(traceLevel) ? "Error" : traceLevel);

                bool isVerbose;
                Boolean.TryParse(ConfigurationManager.AppSettings["SYSTEM_DIAGNOSTICS_TRACE_IS_VERBOSE"], out isVerbose);
                SystemTraceIsVerbose = isVerbose;

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        public static string SystemUserDb
        {
            get { return HttpContext.Current.Application["system_user_db"].ToString(); }
        }   

        public static class Security
        {
            private static readonly object _lock = new Object();

            private static byte[] _conneXionsKey;
            private static string _conneXionsPwd;
            private static RSACryptoServiceProvider _privateKey;
            private static List<IpAddressRange> _allowedIPs;
            private static string _basicAuth;
            private static string _openIdEndpoint;
            private static string[] _openIdAudiences;
            private static string[] _openIdIssuers;

            public static RSACryptoServiceProvider PrivateKey
            {
                get { return _privateKey; }
                private set
                {
                    _privateKey = value;
                }
            }

            public static byte[] ConneXionsRsapkcs1Modulus { get; private set; }
            public static byte[] ConneXionsRsapkcs1Exponent { get; private set; }

            public static bool isJwtDecryptEnabled { get; private set; }

            public static int JwtExpirationMinutes { get; private set; }
            
            public static bool isIPFilterEnabled { get; private set; }

            public static bool isJwtCacheEnabled { get; private set; }

            public static bool isRACEnabled { get; private set; }

            public static List<IpAddressRange> AllowedIPs
            {
                get { return _allowedIPs; }
            }

            public static string BasicAutentication
            {
                get { return _basicAuth; }
            }

            public static string OpenIdEndpoint
            {
                get { return _openIdEndpoint; }
            }

            public static string[] ValidAudiences
            {
                get { return _openIdAudiences; }
            }

            public static string[] ValidIssuers
            {
                get { return _openIdIssuers; }
            }

            static Security() {
                lock (_lock)
                {                  
                    //isJwtDecryptEnabled = bool.Parse(ConfigurationManager.AppSettings["JWT_DECRYPT"]);
                    //isIPFilterEnabled = bool.Parse(ConfigurationManager.AppSettings["IP_FILTER_ENABLED"]);
                    //isJwtCacheEnabled = bool.Parse(ConfigurationManager.AppSettings["JWT_CACHE_ENABLED"]);

                    bool isJwtDecryptEnabledAux;
                    Boolean.TryParse(ConfigurationManager.AppSettings["JWT_DECRYPT"], out isJwtDecryptEnabledAux);
                    isJwtDecryptEnabled = isJwtDecryptEnabledAux;

                    bool isIPFilterEnabledAux;
                    Boolean.TryParse(ConfigurationManager.AppSettings["IP_FILTER_ENABLED"], out isIPFilterEnabledAux);
                    isIPFilterEnabled = isIPFilterEnabledAux;

                    bool isJwtCacheEnabledAux;
                    Boolean.TryParse(ConfigurationManager.AppSettings["JWT_CACHE_ENABLED"], out isJwtCacheEnabledAux);
                    isJwtCacheEnabled = isJwtCacheEnabledAux;

                    bool isRACEnabledAux;
                    Boolean.TryParse(ConfigurationManager.AppSettings["ENABLE_RAC_SECURITY"], out isRACEnabledAux);
                    isRACEnabled = isRACEnabledAux;

                    try { JwtExpirationMinutes = int.Parse(ConfigurationManager.AppSettings["JWT_EXPIRATION_MIN"]); } catch { JwtExpirationMinutes = 20; }

                    SetAllowedIPs();

                    _basicAuth = ConfigurationManager.AppSettings["BASICAUTHENTICATION"];

                    _openIdEndpoint = ConfigurationManager.AppSettings["AZUREAD_OPENID_ENDPOINT"];

                    _openIdAudiences = ConfigurationManager.AppSettings["AZUREAD_OPENID_AUDIENCES"].Split(',');

                    _openIdIssuers = ConfigurationManager.AppSettings["AZUREAD_OPENID_ISSUERS"].Split(',');

                    if (ConneXionsRsapkcs1Modulus == null)
                        ConneXionsRsapkcs1Modulus = GenericFunc.FromBase64Url(ConfigurationManager.AppSettings["RSAPKCS1MODULUS"]);

                    if (ConneXionsRsapkcs1Exponent == null)
                        ConneXionsRsapkcs1Exponent = GenericFunc.FromBase64Url(ConfigurationManager.AppSettings["RSAPKCS1EXPONENT"]);

                    if (_conneXionsKey == null || _conneXionsKey.Length == 0)
                        _conneXionsKey = Convert.FromBase64String(ConfigurationManager.AppSettings["JWT_KEY"]);

                    if (string.IsNullOrEmpty(_conneXionsPwd))
                        _conneXionsPwd = ConfigurationManager.AppSettings["JWT_KEY_PWD"];

                    //var certificate = new X509Certificate2(_conneXionsKey, _conneXionsPwd, X509KeyStorageFlags.Exportable | X509KeyStorageFlags.MachineKeySet);//, X509KeyStorageFlags.Exportable | X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet);
                    //using (certificate.GetRSAPrivateKey()) { }

                    var certificate = LoadJwtCertificate();

                    PrivateKey = certificate.PrivateKey as RSACryptoServiceProvider;
                }
            }

            private static X509Certificate2 LoadJwtCertificate()
            {
                var tempFile = Path.Combine(Path.GetTempPath(), "JwtCert-" + Guid.NewGuid());
                X509Certificate2 certificate = null;
                try
                {
                    File.WriteAllBytes(tempFile, _conneXionsKey);
                    certificate = new X509Certificate2(tempFile, _conneXionsPwd,
                        X509KeyStorageFlags.Exportable | X509KeyStorageFlags.UserKeySet);
                    using (certificate.GetRSAPrivateKey()) { }                    
                }
                catch (Exception)
                {
                    certificate = new X509Certificate2(_conneXionsKey, _conneXionsPwd,
                        X509KeyStorageFlags.Exportable | X509KeyStorageFlags.UserKeySet);

                    using (certificate.GetRSAPrivateKey()) { }
                }
                finally
                {
                    if (File.Exists(tempFile))
                    {
                        File.Delete(tempFile);
                    }
                }

                return certificate;
            }

            private static void SetAllowedIPs() {
                
                _allowedIPs = new List<IpAddressRange>();

                var list = ConfigurationManager.AppSettings["ALLOWED_IPS"].Replace(" ", "");

                foreach (var ip in list.Split(','))
                {
                    //check for ip range
                    if (ip.Contains("-"))
                    {
                        var range = ip.Split('-');

                        if (IpAddressRange.IsValidIp(range[0]) && IpAddressRange.IsValidIp(range[1]))
                        {
                            _allowedIPs.Add(new IpAddressRange(IPAddress.Parse(range[0]), IPAddress.Parse(range[1])));
                        }

                    }
                    else
                    {
                        if (IpAddressRange.IsValidIp(ip))
                        {
                            _allowedIPs.Add(new IpAddressRange(IPAddress.Parse(ip), IPAddress.Parse(ip)));
                        }
                    }
                }
            }        
        }
    }
}
