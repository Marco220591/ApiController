﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIController.Exceptions
{
    public class JwtException : AuthorizationException
    {
        public JwtException() { }
        public JwtException(string message) : base(message) { }
        public JwtException(string message, Exception inner) : base(message, inner) { }
    }
}