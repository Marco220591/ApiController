﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIController.Exceptions
{
    public class BussinessException : System.Exception
    {
        public BussinessException() { }
        public BussinessException(string message) : base(message) { }
        public BussinessException(string message, Exception inner) : base(message, inner) { }
    }
}