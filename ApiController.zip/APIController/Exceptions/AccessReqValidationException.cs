﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIController.Exceptions
{
    public class AccessReqValidationException : System.Exception
    {
        public AccessReqValidationException() { }
        public AccessReqValidationException(string message) : base(message) { }
        public AccessReqValidationException(string message, Exception inner) : base(message, inner) { }
    }
}