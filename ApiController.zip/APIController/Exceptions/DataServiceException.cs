﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIController.Exceptions
{
    public class DataServiceException : System.Exception
    {
        public DataServiceException() { }
        public DataServiceException(string message) : base(message) { }
        public DataServiceException(string message, Exception inner) : base(message, inner) { }
    }
}