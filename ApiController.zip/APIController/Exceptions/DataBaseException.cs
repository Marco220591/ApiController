﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIController.Exceptions
{
    public class DataBaseException : System.Exception
    {
        public DataBaseException() { }
        public DataBaseException(string message) : base(message) { }
        public DataBaseException(string message, Exception inner) : base(message, inner) { }
    }
}