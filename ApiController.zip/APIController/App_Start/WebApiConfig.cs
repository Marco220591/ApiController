﻿using APIController.Handlers;
using Newtonsoft.Json;
using System;
using System.Globalization;
using System.Threading;
using System.Web.Http;
using System.Diagnostics;
using CxUtilities.Logger;
using System.Web.Http.Tracing;
using APIController.Core;

namespace APIController
{
    public static class WebApiConfig
    {        
        private static Core.ApiEngine _engineRef;           

        public static void Register(HttpConfiguration config)
        {
            CxLog.Debug(Core.ApiEngine._tag, Core.ApiEngine._source, "API Controller Loading at: " + GlobalInfo.SystemName);           

            // Web API configuration and services
            //System.Configuration.app .AppSettings["InstrumentationKey"];            

            if (string.IsNullOrEmpty(
                System.Configuration.ConfigurationManager.AppSettings["APPLICATIONINSIGHTS_CONNECTION_STRING"]))
            {
                Microsoft.ApplicationInsights.Extensibility.TelemetryConfiguration.Active.InstrumentationKey =
                    System.Configuration.ConfigurationManager.AppSettings["APPINSIGHTS_INSTRUMENTATIONKEY"];
            }
            else
            {
                Microsoft.ApplicationInsights.Extensibility.TelemetryConfiguration.Active.ConnectionString = System.Configuration.ConfigurationManager.AppSettings["APPLICATIONINSIGHTS_CONNECTION_STRING"];
            }                        

            _engineRef = Core.ApiEngine.GetInstance(GlobalInfo.ConnectionName, config);

            // Serializer config to skip or ignore all properties that have null in the json response 
            config.Formatters.JsonFormatter.SerializerSettings = new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore };

            // app-insights-asp-net-exceptions
            SystemDiagnosticsTraceWriter diagnosticsTrace = config.EnableSystemDiagnosticsTracing();
            diagnosticsTrace.IsVerbose = GlobalInfo.SystemTraceIsVerbose;
            diagnosticsTrace.MinimumLevel = GlobalInfo.SystemTraceLevel;

            // Web API configuration and services
            CultureInfo culture = (CultureInfo)CultureInfo.CurrentCulture.Clone();
            culture.DateTimeFormat.ShortDatePattern = "yyyy-MM-dd";
            culture.DateTimeFormat.LongTimePattern = "yyyy-MM-ddTHH:mm:ss";
            culture.DateTimeFormat.FullDateTimePattern = "yyyy-MM-ddTHH:mm:ss";
            Thread.CurrentThread.CurrentCulture = culture;

            var json = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            json.SerializerSettings.Culture = culture;
            json.SerializerSettings.DateFormatString = "yyyy-MM-ddTHH:mm:ss";

            //var formatters = GlobalConfiguration.Configuration.Formatters;
            //formatters.FormUrlEncodedFormatter
            //formatters.Remove(formatters.XmlFormatter);
            // Web API routes
            config.MapHttpAttributeRoutes();

            //#if !DEBUG
            config.MessageHandlers.Add(new AuthorizationHandler());
            //#endif
            AppDomain.CurrentDomain.AssemblyResolve += ApiAssembliesResolver.CurrentDomain_AssemblyResolve;
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(ApiAssembliesResolver.CurrentDomain_UnhandledException);
            
            //Core.ApiProcess.InitializeAssemblies(config);            

            //config.Routes.MapHttpRoute(
            //    name: "DefaultApi",
            //    routeTemplate: "api/{version}/{controller}/{action}/{id}",
            //    defaults: new { id = RouteParameter.Optional }
            ////constraints: null,
            ////handler: new RequestHandler()
            //);

            //_engineRef = Core.ApiEngine.GetInstance(GlobalInfo.ConnectionName, config);
            var engt = Stopwatch.StartNew();
            _engineRef.MapHttpRoutes();
            engt.Stop();
            CxLog.Debug(ApiEngine._tag, ApiEngine._source,
                "Map Http Routes took: " + engt.ElapsedMilliseconds.ToString() + " ms. : " + GlobalInfo.SystemName);

            engt = Stopwatch.StartNew();
            _engineRef.SetupSelfHealing();
            engt.Stop();
            CxLog.Debug(ApiEngine._tag, ApiEngine._source,
                "Setup Self-Healing took: " + engt.ElapsedMilliseconds.ToString() + " ms. : " + GlobalInfo.SystemName);
            //config.MessageHandlers.Add(new RequestHandler());

            CxLog.Debug(Core.ApiEngine._tag, Core.ApiEngine._source, "API Controller Loaded at: " + GlobalInfo.SystemName);
        }

        #region AssemblyResolve
        /*
        private static void DiscoverAssemblies(DirectoryInfo path)
        {
            try
            {
                var files = path.GetFiles().Where(f => f.Extension.Equals(".dll", StringComparison.Ordinal));                

                foreach (var f in files)
                {
                    FileVersionInfo fvi = null;
                    try
                    {
                        fvi = FileVersionInfo.GetVersionInfo(f.FullName);
                    }
                    catch (Exception exc)
                    {
                        CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource, "couldn't GetVersionInfo of: " + f.FullName, exc);
                        continue;
                    }

                    var file = new Tuple<string, FileInfo, FileVersionInfo>(f.FullName, f, fvi);
                    _assembliesList.Add(file);
                }

                foreach (var d in path.GetDirectories())
                {
                    DiscoverAssemblies(d);
                }
            }
            catch (System.Exception ex)
            {
                CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource, "DiscoverAssemblies method failed! => " + path.FullName, ex);
            }
        }
        */
        /*
        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            try
            {
                Exception ex = (Exception) e.ExceptionObject;
                var msg = "Unhandled Exception Ocurred, IsTerminating: " + e.IsTerminating + ", Args:" + JsonConvert.SerializeObject(e) + ", " + JsonConvert.SerializeObject(sender) + " : " + GlobalInfo.SystemName;
                CxLog.Error(Core.ApiEngine._tag, Core.ApiEngine._source, msg, ex);
            }
            catch (Exception ex)
            {
                var msg = "Unhandled Exception Ocurred, error while getting the exeption: " +
                          JsonConvert.SerializeObject(e) + ", " + JsonConvert.SerializeObject(sender) + " : " + GlobalInfo.SystemName;
                CxLog.Error(Core.ApiEngine._tag, Core.ApiEngine._source, msg, ex);
            }
        }
        
        private static Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            var vStr = "Version=";
            var vIdx = args.Name.IndexOf(vStr, StringComparison.Ordinal) + vStr.Length;
            var name = args.Name.Substring(0, args.Name.IndexOf(','));
            var version = args.Name.Substring(vIdx, args.Name.IndexOf(',', vIdx) - vIdx).Trim().Split('.').Select(t => int.Parse(t)).ToArray();

            //var asmTime = Stopwatch.StartNew();

            var assembly = AppDomain.CurrentDomain.GetAssemblies().AsParallel().FirstOrDefault(a => a.FullName == args.Name);

            //asmTime.Stop();

            //CxLog.Log(LogType.Warn, "Search Assembly in Current Domain: " + asmTime.ElapsedMilliseconds.ToString() + " ms. : <" + args.Name + "> " +
            //                            GlobalInfo.SystemName, Core.ApiEngine._tag,
            //        asmTime.ElapsedMilliseconds.ToString(), Core.ApiEngine._source, null, null);            

            if (assembly != null)
                return assembly;

            try
            {                
                assembly = FindAssembly(name, version, args.Name, args.RequestingAssembly);
            }
            catch (Exception ex)
            {
                var aex = new ApplicationException(args.RequestingAssembly?.FullName + " --> " + args.Name + " : " + GlobalInfo.SystemName, ex);
                CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource, aex);
            }

            return assembly;
        }

        private static Assembly FindAssembly(string name, int[] version, string fullName, Assembly reference = null)
        {
            var original = name + ".dll";

            var files = from f in _assembliesList.AsParallel()
                where f.Item3.OriginalFilename != null &&
                      f.Item3.OriginalFilename.Equals(original, StringComparison.OrdinalIgnoreCase)
                select f;

            ConcurrentBag<Assembly> assembliesExact = new ConcurrentBag<Assembly>();
            ConcurrentBag<Assembly> assemblies = new ConcurrentBag<Assembly>();

            Parallel.ForEach(files, file =>
            {

                var eq = true;
                var pversioneq = CompareVersion(version, file.Item3.ProductVersion);
                var fversioneq = CompareVersion(version, file.Item3.FileVersion);

                eq = pversioneq || fversioneq;
                try
                {
                    var assembly = GetAssembly(file.Item2.FullName);

                    if (assembly.FullName == fullName)
                    {
                        assembliesExact.Add(assembly);
                    }
                    else if (eq)
                    {
                        assemblies.Add(assembly);
                    }

                }
                catch (Exception ex)
                {
                    var nex = new FileLoadException(
                        file.Item2.FullName + " -- " + file.Item3.OriginalFilename + " -- " + file.Item3.ProductVersion,
                        ex);
                    CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource, "Requesting Assembly: " + reference?.FullName + " : " + GlobalInfo.SystemName,
                        nex);
                }
            });

            var exactMatches = false;
            var possibleMatches = false;

            if (assembliesExact.Count == 0)
            {
                CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource,
                    "Requested Assembly has no extact matches: " + original + " : " + GlobalInfo.SystemName, null);
            }
            else if (assembliesExact.Count > 0)
            {
                CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource,
                    "Requested Assembly has exact matches: " + assembliesExact.Count + " : " + original + " : " + GlobalInfo.SystemName, null);
                exactMatches = true;
            }

            if (assemblies.Count == 0)
            {
                CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource,
                    "Requested Assembly has no possible matches: " + original + " : " + GlobalInfo.SystemName, null);
            }
            else if (assemblies.Count > 0)
            {
                CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource,
                    "Requested Assembly has possible matches: " + assemblies.Count + " :  + original" + " : " + GlobalInfo.SystemName, null);

                possibleMatches = true;
            }

            if (exactMatches)
                return assembliesExact.First();
            else if (possibleMatches)
                return assemblies.First();


            return null;
        }
        */
        //private static Assembly FindAssembly(string name, int[] version, string fullName, Assembly reference = null)
        //{
        //    var original = name + ".dll";

        //    var files = from f in _assembliesList.AsParallel()
        //        where f.Item3.OriginalFilename != null &&
        //              f.Item3.OriginalFilename.Equals(original, StringComparison.OrdinalIgnoreCase)
        //        select f;            

        //    foreach (var file in files)
        //    {

        //        var eq = true;
        //        var pversioneq = CompareVersion(version, file.Item3.ProductVersion);
        //        var fversioneq = CompareVersion(version, file.Item3.FileVersion);

        //        eq = pversioneq || fversioneq;
        //        try
        //        {
        //            var assembly = GetAssembly(file.Item2.FullName);

        //            if (eq || assembly.FullName == fullName)
        //                return assembly;

        //        }
        //        catch (Exception ex)
        //        {
        //            var nex = new FileLoadException(file.Item2.FullName + " -- " + file.Item3.OriginalFilename + " -- " + file.Item3.ProductVersion, ex);
        //            CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource, "Requesting Assembly: " + reference?.FullName, nex);
        //        }
        //    }

        //    return null;
        //}

        //private static Assembly FindAssembly(string name, int[] version, string fullName, Assembly reference = null)
        //{
        //    var original = name + ".dll";            

        //    var files = _assembliesList.Where(
        //        f => f.Item3.OriginalFilename != null &&
        //             f.Item3.OriginalFilename.Equals(original, StringComparison.OrdinalIgnoreCase));

        //    foreach (var file in files)
        //    {

        //        var eq = true;
        //        var pversioneq = CompareVersion(version, file.Item3.ProductVersion);
        //        var fversioneq = CompareVersion(version, file.Item3.FileVersion);

        //        eq = pversioneq || fversioneq;
        //        try
        //        {
        //            var assembly = GetAssembly(file.Item2.FullName);

        //            if (eq || assembly.FullName == fullName)
        //                return assembly;

        //        }
        //        catch (Exception ex)
        //        {
        //            var nex = new FileLoadException(file.Item2.FullName + " -- " + file.Item3.OriginalFilename + " -- " + file.Item3.ProductVersion, ex);
        //            CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource, "Requesting Assembly: " + reference?.FullName, nex);
        //        }
        //    }                 

        //    return null;
        //}

        /*
        private static Assembly FromAssembly(string name, int[] version, string fullName, DirectoryInfo reference, bool inmediateFiles = true)
        {
            var original = name + ".dll";
            if (inmediateFiles)
            {
                var files = reference.GetFiles().Where(f => f.Extension.Equals(".dll", StringComparison.Ordinal));
                foreach (var file in files)
                {
                    FileVersionInfo fvi = null;

                    try
                    {
                        fvi = FileVersionInfo.GetVersionInfo(file.FullName);
                    }
                    catch (Exception exc)
                    {
                        CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource, "couldn't GetVersionInfo of: " + file.FullName, exc);
                        continue;                        
                    }

                    if (fvi.OriginalFilename != null && fvi.OriginalFilename.Equals(original, StringComparison.OrdinalIgnoreCase))
                    {
                        var eq = true;
                        var pversioneq = CompareVersion(version, fvi.ProductVersion);
                        var fversioneq = CompareVersion(version, fvi.FileVersion);

                        eq = pversioneq || fversioneq;
                        try
                        {
                            var assembly = GetAssembly(file.FullName);

                            if (eq || assembly.FullName == fullName)
                                return assembly;

                            //if (eq)
                            //    return Assembly.LoadFrom(file.FullName);
                            //else
                            //{
                            //    var assembly = Assembly.ReflectionOnlyLoadFrom(file.FullName);
                            //    if (assembly.FullName == fullName)
                            //        return Assembly.LoadFrom(file.FullName);
                            //}
                        }
                        catch (Exception ex)
                        {
                            var nex = new FileLoadException(reference.FullName + " -- " + fvi.OriginalFilename + " -- " + fvi.ProductVersion, ex);
                            CxLog.Warn(AssemblyResolveTag, AssemblyResolveSource, nex);
                        }
                    }
                }
            }

            foreach (var directory in reference.GetDirectories())
            {
                var assembly = FromAssembly(name, version, fullName, directory);
                if (assembly != null)
                    return assembly;
            }

            return null;
        }
        
        private static Assembly FromAssembly(string name, int[] version, string fullName, Assembly reference, bool inmediateFiles = true)
        {
            if (string.IsNullOrEmpty(reference.Location))
                return null;
            var rAssembly = new FileInfo(reference.Location);
            return FromAssembly(name, version, fullName, rAssembly.Directory, inmediateFiles);
        }
        */

        //private static bool CompareVersion(int[] source, string target)
        //{
        //    var eq = true;

        //    var version = target.Trim().Split('.').Select(t =>
        //    {
        //        var r = Regex.Match(t, "(\\d)*").Value;
        //        return int.Parse(string.IsNullOrEmpty(r) ? "0" : r);
        //    }).ToArray();

        //    if (version.Length == 0)
        //        return false;

        //    for (int idx = 0; idx < 5; idx++)
        //    {
        //        if ((idx < version.Length ? version[idx] : 0) != (idx < source.Length ? source[idx] : 0))
        //        {
        //            eq = false;
        //            break;
        //        }
        //    }

        //    return eq;
        //}

        /*
        private static Assembly GetAssembly(string path)
        {
            FileStream file = null;
            Assembly asm = null;
            try
            {
                file = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                if (file.CanRead)
                {
                    asm = Assembly.LoadFrom(path);
                }
                else
                {
                    throw new FileLoadException("Assembly cannot be loaded/readed");
                }
            }
            finally
            {
                file?.Close();
            }

            return asm;
        }
        */

        //private static Assembly GetAssembly(string path)
        //{
        //    FileStream file = null;
        //    Assembly asm = null;

        //    using (file = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
        //    {
        //        if (file.CanRead)
        //        {
        //            asm = Assembly.LoadFrom(path);
        //        }
        //        else
        //        {
        //            throw new FileLoadException("Assembly cannot be loaded/readed");
        //        }
        //    }

        //    return asm;
        //}

        #endregion
    }
}
