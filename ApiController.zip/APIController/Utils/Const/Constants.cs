﻿namespace APIController.Utils.Const
{

    public static class CommandType
    {

        public static char Assembly = 'A';
        public static char StoreProcedure = 'S';
        public static char Function = 'F';
        public static char View = 'V';
        public static char Query = 'Q';

    }
    public static class HttpVerv
    {

        public static char Get = 'G';
        public static char Post = 'P';
        public static char Put = 'U';
        public static char Delete = 'D';

    }
}