﻿using System;
using System.Data.Common;
using CxUtilities.Logger;
using System.Security.Cryptography;
using System.Text;

namespace APIController.Utils
{
    public class GenericFunc
    {
        private readonly DbConnection _db;
        public GenericFunc()
        {
            _db = CxUtilities.DataConection.CxConnection.CreateDbConnectionByName(GlobalInfo.ConnectionName);
        }
        internal string GetSystemUser()
        {
            string result = null;
            var com = _db.CreateCommand();
            com.Connection = _db;
            com.CommandText = "SELECT system_user ";
            try
            {
                com.Connection.Open();
                result = com.ExecuteScalar().ToString();   
            }
            catch(Exception e)
            {
                CxLog.Log(e);
            }
            finally
            {
                _db.Close();
            }
            return result;
        }    

        public bool ExistsLanguage(string locale)
        {
            string result = null;
            var q = @"IF EXISTS(SELECT (LanguageId)
                    FROM   cnxmstrdata.LanguageCat 
                    WHERE LanguageCode = '" + locale + "')SELECT CAST(1 AS BIT) ELSE  SELECT CAST(0 AS Bit)";
            var com = _db.CreateCommand();
            com.Connection = _db;
            com.CommandText = q;
            try
            {
                com.Connection.Open();
                result = com.ExecuteScalar().ToString();

            }
            catch (Exception e)
            {
                CxLog.Log(e);
            }
            finally
            {
                _db.Close();
            }
            return result != null && bool.Parse(result);
        }

        public static byte[] FromBase64Url(string base64Url)
        {
            string padded = base64Url.Length % 4 == 0
                ? base64Url : base64Url + "====".Substring(base64Url.Length % 4);
            string base64 = padded.Replace("_", "/")
                                  .Replace("-", "+");
            return Convert.FromBase64String(base64);
        }

        public static string GetMd5Hash(string input)
        {
            using (MD5 md5Hash = MD5.Create())
            {
                // Convert the input string to a byte array and compute the hash.
                byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

                // Create a new Stringbuilder to collect the bytes
                // and create a string.
                StringBuilder sBuilder = new StringBuilder();

                // Loop through each byte of the hashed data 
                // and format each one as a hexadecimal string.
                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }

                // Return the hexadecimal string.
                return sBuilder.ToString();
            }
        }
    }
}