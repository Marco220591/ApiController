﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Security.Claims;
using System.Security.Cryptography;
using System.IdentityModel.Tokens.Jwt;
using CxUtilities.Exceptions;
using System.Threading;
using System.Threading.Tasks;
using CxUtilities.Logger;
using CxUtilities.Network;
using APIController.Core;
using APIController.Utils;
using System.Runtime.Caching;
using APIController.Models.Core;
using System.Net.Http.Headers;
using CxUtilities.DataConection;
using System.Data.Common;
using CxUtilities.Extensions;
using System.Text.RegularExpressions;
using APIController.Core.Constants;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Tokens;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;

namespace APIController.Handlers
{
    public class AuthorizationHandler : DelegatingHandler
    {
        private const string _tag = "ATH";
        private const string _source = "AuthHandler";
        private const string _legacyProvider = "CEMEX";
        private static ObjectCache _cache = MemoryCache.Default;
        private static readonly string GuidPattern = @"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}";
        private static readonly RegexOptions RxOptions = RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant | RegexOptions.Compiled;
        private static readonly Regex TenantRegex = new Regex(GuidPattern, RxOptions);

        private static GenericIdentity GetFromCache(string key)
        {            
            return _cache.Get(GenericFunc.GetMd5Hash(key)) as GenericIdentity;
        }

        private static void SetCache(string key, GenericIdentity identity)
        {
            //CacheItemPolicy policy = new CacheItemPolicy { SlidingExpiration = TimeSpan.FromMinutes(20) };
            CacheItemPolicy policy = new CacheItemPolicy { AbsoluteExpiration = DateTimeOffset.Now.AddMinutes(GlobalInfo.Security.JwtExpirationMinutes) };
            _cache.Add(GenericFunc.GetMd5Hash(key), identity, policy);
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            ApiPath path = null;
            try
            {
                path = request.GetRouteData().Route.Defaults[ApiEngine._apiPath] as ApiPath;

                if (path == null)
                    throw new NotImplementedException(request.RequestUri.AbsolutePath + " not Found!");

                var identity = ParseAuthorizationHeader(request, path);
                if (identity == null)
                {
                    throw new AuthorizationException(
                        "OnAuthorization Error at: " + path.ApiCode + ": " + request.RequestUri.AbsolutePath + ": " +
                        GlobalInfo.SystemName,
                        new ErrorDto(ReasonMessage.CredentialsRequired.Code, ReasonMessage.CredentialsRequired.Description, "Unauthorized", HttpCodes.Unauthorized));
                }
            }
            catch (Exception e)
            {
                CxLog.Error(_tag, _source, e);
                var resp = ExceptionHandler.OnException(e);
                var tsc = new TaskCompletionSource<HttpResponseMessage>();
                tsc.SetResult(resp);
                return await tsc.Task;
            }

            try
            {
                var response = await base.SendAsync(request, cancellationToken);
                //ApiEngine.collectMemory();
                return response;
            }
            catch (Exception e)
            {
                var info = "ApiCode: " + path.ApiCode + " -- " + path.Status + " -- ";

                if (e.InnerException != null && e.InnerException is DllNotFoundException)
                    CxLog.Error(ApiEngine._tag, ApiEngine._source, new ApplicationException(info + request.RequestUri.AbsolutePath + " -- dll Not Found: " + GlobalInfo.SystemName, e));
                else
                    CxLog.Error(ApiEngine._tag, ApiEngine._source, new ApplicationException(info + request.RequestUri.AbsolutePath + " -- Internal Error: " + GlobalInfo.SystemName, e));
                //ApiEngine.collectMemory();
                var resp = ExceptionHandler.OnException(e);
                var tsc = new TaskCompletionSource<HttpResponseMessage>();
                tsc.SetResult(resp);
                return await tsc.Task;
            }
        }

        private GenericIdentity ParseAuthorizationHeader(HttpRequestMessage request, ApiPath path)
        {            
            var auth = GetAuthenticationHeader(request, path);

            if (auth == null) return null;

            var authHeader = auth.Parameter;

            if (auth.Scheme == "Bearer")
            {
                var identity = ParseBearerAuthentication(request, path, authHeader);

                if (identity == null || !OnAuthorizeBearerUser(identity.Name, identity.AuthenticationType))
                {
                    throw new JwtException("Unauthorized: " + request.RequestUri.AbsolutePath,
                        new ErrorDto(ReasonMessage.InvalidCredentials.Code,
                            ReasonMessage.InvalidCredentials.Description, "Unauthorized",
                            ReasonMessage.InvalidCredentials.HttpCode));
                }

                //User Role Permissions
                if (GlobalInfo.Security.isRACEnabled)
                {
                    checkRoleAuthorization(path, identity);
                }

                HttpContext.Current.User = new ClaimsPrincipal(identity);
                return identity;
            }
            else if (auth.Scheme == "Basic")
            {
                //Check if the client is Allowed to connect
                if (!AuthorizedConnection(path))
                {
                    throw new BasicAuthException("Forbidden: " + request.RequestUri.AbsolutePath,
                        new ErrorDto(ReasonMessage.ClientNotAllowed.Code, ReasonMessage.ClientNotAllowed.Description,
                            "Forbidden", ReasonMessage.ClientNotAllowed.HttpCode));
                }

                var identity = ParseBasicAuthentication(authHeader);
                if (identity == null || !OnAuthorizeBasicUser((BasicAuthenticationIdentity) identity, request))
                {
                    throw new BasicAuthException("Unauthorized: " + request.RequestUri.AbsolutePath,
                        new ErrorDto(ReasonMessage.InvalidCredentials.Code,
                            ReasonMessage.InvalidCredentials.Description, "Unauthorized",
                            ReasonMessage.InvalidCredentials.HttpCode));
                }

                var principal = new GenericPrincipal(identity, null);
                Thread.CurrentPrincipal = principal;
                return identity;
            }

            return null;
        }

        private AuthenticationHeaderValue GetAuthenticationHeader(HttpRequestMessage request, ApiPath path)
        {
            var auth = request.Headers.Authorization;

            if (string.IsNullOrEmpty(auth?.Scheme) || string.IsNullOrEmpty(auth?.Parameter))
            {
                if (SetByPassAuthentication(request, path))
                    auth = request.Headers.Authorization;
                else
                    return null;
            }

            return auth;
        }

        private bool SetByPassAuthentication(HttpRequestMessage request, ApiPath path)
        {            
            if (path.isAuthDisabled)
                request.Headers.Authorization = new AuthenticationHeaderValue("Basic", GlobalInfo.Security.BasicAutentication);            

            return path.isAuthDisabled;
        }

        //private string GetAuthenticationType(HttpRequestMessage request)
        //{
        //    var auth = request.Headers.Authorization;
        //    if (string.IsNullOrEmpty(auth?.Scheme)) return null;
        //    var authHeader = auth.Parameter;

        //    return string.IsNullOrEmpty(authHeader) ? null : auth.Scheme;
        //}

        private GenericIdentity ParseBasicAuthentication(string authHeader)
        {
            try
            {
                authHeader = Encoding.Default.GetString(Convert.FromBase64String(authHeader));

                // find first : as password allows for :
                var idx = authHeader.IndexOf(':');
                if (idx < 0)
                    return null;

                var username = authHeader.Substring(0, idx);
                var password = authHeader.Substring(idx + 1);

                return new BasicAuthenticationIdentity(username, password);
            }
            catch (Exception e)
            {
                CxLog.Error(_tag, _source, e);
                return null;
            }
        }

        private GenericIdentity ParseBearerAuthentication(HttpRequestMessage request, ApiPath path,  string authHeader)
        {
            
            GenericIdentity identity;

            try
            {
                //Cached tokens
                if (GlobalInfo.Security.isJwtCacheEnabled)
                {
                    identity = GetFromCache(authHeader);
                    if (identity != null)
                        return identity;
                }

                var localeHeader = request.Headers.AcceptLanguage.DefaultIfEmpty(null).FirstOrDefault();
                const string appCodeHeader = "App-Code";
                const string appPushHeader = "bm-env";
                var appPushEnv = "";
                var appCode = "";

                if (request.Headers.Contains(appPushHeader))
                    appPushEnv = request.Headers.GetValues(appPushHeader).DefaultIfEmpty(null).FirstOrDefault();

                if (request.Headers.Contains(appCodeHeader))
                    appCode = request.Headers.GetValues(appCodeHeader).DefaultIfEmpty(null).FirstOrDefault();

                var locale = localeHeader?.Value;

                JwtSecurityToken jwt;

                if (!ValidateJwt(path, authHeader, out jwt))
                {
                    return null;
                }
                
                var claims = (Dictionary<string, object>)jwt.Payload;
                var userKeyLegacy = "userprincipalname";
                var userKeyAAD = "onpremisessamaccountname";
                var userKeyB2C = "extension_upn";
                string user = null;

                try
                {
                    if (claims.ContainsKey(userKeyLegacy))
                    {
                        user = claims[userKeyLegacy].ToString();
                    }
                    else if (claims.ContainsKey(userKeyAAD)) 
                    {
                        //these lines have to do with the mapping in the Azure AD, these configuation was made for internal users
                        //to be able to SSO with CEMEX Azure AD, the user account is considered to be the cemex id as it is on cemex go accounts.
                        user = claims[userKeyAAD].ToString();
                        claims.Add("mail", claims["email"].ToString());
                    }
                    else if (claims.ContainsKey(userKeyB2C))
                    {
                        //these lines have to do with the mapping in the Azure B2C, these configuation was made for external users                        
                        user = claims[userKeyB2C].ToString();
                        claims.Add("mail", claims["extension_mail"].ToString());

                        if (claims.ContainsKey("extension_countrycode"))
                            claims.Add("countrycode", claims["extension_countrycode"].ToString()); //country numeric

                        claims.Add("ctry", claims["country"].ToString()); //country alpha-2
                    }
                }
                catch (Exception ex)
                {
                    CxLog.Error(_tag, _source, new Exception("Error while reading claims from token at: " + request.RequestUri.AbsolutePath + " token: " + authHeader + " : " + GlobalInfo.SystemName, ex));
                    return null;
                }

                identity = new GenericIdentity(user, "Bearer");
                foreach (var claim in claims)
                {
                    identity.AddClaim(new Claim(claim.Key, claim.Value.ToString()));
                }

                if (locale != null) identity.AddClaim(new Claim("locale", locale));
                if (appCode != null) identity.AddClaim(new Claim("appcode", appCode));
                if (appPushEnv != null) identity.AddClaim(new Claim("appenv", appPushEnv));

                //Save tokens to cache
                if (GlobalInfo.Security.isJwtCacheEnabled)
                    SetCache(authHeader, identity);
            }
            catch (Exception e)
            {
                CxLog.Error(_tag, _source, new Exception("Error Parsing Token at: " + request.RequestUri.AbsolutePath + " token: " + authHeader +" : " + GlobalInfo.SystemName, e));
                return null;
            }

            return identity;
        }

        #region JWT Auth validation methods

        //private static string _conneXionsRsapkcs1Modulus;
        //private static string _conneXionsRsapkcs1Exponent;
        //private static byte[] _conneXionsKey;
        //private static string _conneXionsPwd;

        private void checkRoleAuthorization(ApiPath path, GenericIdentity identity)
        {
            //ApiPath apiPath = request.GetRouteData().Route.Defaults[ApiEngine._apiPath] as ApiPath;
            String userAccount = identity?.Name;
            var roleAccessSP = "usp_secm_UserValidateAPIAccess";

            using (DbConnection connection = CxConnection.CreateDbConnectionByName("DB_CNXMD"))
            {
                try
                {
                    connection.Open();
                    DbCommand cmd = connection.CreateSPCommand(roleAccessSP);
                    cmd.CreateParameter("@UrlApiPath", null);
                    cmd.CreateParameter("@UserAccount", userAccount);
                    cmd.CreateParameter("@UserId", null);
                    cmd.CreateParameter("@ApiPathId", path.APIPathId);

                    var isAllowed = ((int)cmd.ExecuteScalar() == 1);
                   
                    if (!isAllowed)
                    {
                        throw new AuthorizationException("OnAuthorization Error at: " + path.APIPathId + ": " + path.HTTPMethod + ": " + path.URLPath + ", User: " + userAccount + " Not Allowed: " + GlobalInfo.SystemName);
                    }
                }
                catch (Exception ex)
                {
                    throw new AuthorizationException("OnAuthorization Database Error at: " + roleAccessSP + ", for: " + path.URLPath + ", APIPathId: " + path.APIPathId + ", User: " + userAccount + ": " + GlobalInfo.SystemName, ex);                    
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private static bool ValidateJwt(ApiPath path, string token, out JwtSecurityToken outToken)
        {
            var result = false;
            outToken = null;
            Exception ex = null;
            Exception aux = null;

            var endpoint = GetJwtProvider(token, out ex);

            if (!string.IsNullOrEmpty(endpoint))
            {

                if (endpoint.Equals(_legacyProvider))
                {
                    result = IsValidJwtDefaultSignature(token, out outToken, out ex);
                }
                else
                {
                    result = isValidJWTAzureAD(token, endpoint, out outToken, out ex);
                }
            }
            else
            {
                aux = new Exception("Cannot determine identity provider for token received: missing provider configuration or token is malformed: " + token, ex);
            }

            if (!result)            
                CxLog.Error(_tag, _source, "Error on AuthorizationHandler.ValidateJwt method", aux ?? ex);

            return result;
        }

        private static string GetJwtProvider(string token, out Exception ex)
        {
            ex = null;
            string tenant = null;

            try
            {
                var handler = new JwtSecurityTokenHandler();
                var jwt = handler.ReadJwtToken(token);

                if ((string.IsNullOrEmpty(jwt.Issuer)) || (jwt.Issuer != null && (
                                                               jwt.Issuer.Equals("CEMEX",
                                                                   StringComparison.InvariantCultureIgnoreCase) ||
                                                               jwt.Issuer.Equals(""))))
                {
                    return _legacyProvider; //This means was provided by the CEMEX legacy JWT
                }

                //Otherwise, it means the token was generated by an identity provider
                //Look for the proper tenant to be used based on the JWT Issuer claim; Multitenant feature, if its only 1 configured, it will take it by default.
                var tenants = GlobalInfo.Security.OpenIdEndpoint.Split(',');

                if (tenants.Length > 1)
                {
                    //var issuer = jwt.Issuer; //jwt.Claims.First(claim => claim.Type == "iss").Value;

                    Match tenantId = TenantRegex.Match(jwt.Issuer);

                    if (!string.IsNullOrEmpty(tenantId?.Value))
                    {
                        for (var i = 0; i < tenants.Length; i++)
                        {
                            if (!tenants[i].Contains(tenantId.Value)) continue;
                            tenant = tenants[i];
                            break;
                        }
                    }
                }
                else
                {
                    tenant = GlobalInfo.Security.OpenIdEndpoint;
                }
            }
            catch (Exception e)
            {
                ex = new Exception("Error while trying to get JWT Provider at: " + GlobalInfo.SystemName + ": " + token, e);
            }

            return tenant;
        }

        private static bool IsValidJwtDefaultSignature(string token, out JwtSecurityToken outToken, out Exception ex)
        {
            //if (string.IsNullOrEmpty(_conneXionsRsapkcs1Modulus))
            //    _conneXionsRsapkcs1Modulus = ConfigurationManager.AppSettings["RSAPKCS1MODULUS"]; //"01XIfjOr6tB-FVm5VkH82PTtpFtEsI3M0nmIDWixLKddtl8JpFFQfKq3ImlumDt0-sXvC4ccDcsGgxwxE99I5Zsga08Vdl5SYISgTg3aN_MLr8cbAq8HLOVJJUjlHAS_SoYcSqAN_h8w-mhUsDtAi2SMms8og7o17xOa7QRQ5uGDAnfTRw-aiLho3904IwY4l4fvNbBu_Kv3OpoEhNfGCJH4htpsnPMb-tXduZiH30I5LiSTKuyYcSgbDZFyQAJJWFG5KiewgdpsU9kMjEYlegNoS7jBRpaa_o5Nk9u7ArMVbB1BEo2eg1Q3Pj9XRvmf22_xYkjRDFl5tYjlnMPV9w";
            //if (string.IsNullOrEmpty(_conneXionsRsapkcs1Exponent))
            //    _conneXionsRsapkcs1Exponent = ConfigurationManager.AppSettings["RSAPKCS1EXPONENT"]; //"AQAB";

            //var jwtDecryptEnabled = bool.Parse(ConfigurationManager.AppSettings["JWT_DECRYPT"]);
            //tokenStr = jwtDecryptEnabled ? JwtDecrypt(token) : token;
            outToken = null;
            ex = null;

            try
            {
                var tokenStr = GlobalInfo.Security.isJwtDecryptEnabled ? JwtDecrypt(token) : token;                

                var tokenParts = tokenStr.Split('.');
                if (tokenParts.Length < 3)
                    return false;

                var rsa = new RSACryptoServiceProvider();
                rsa.ImportParameters(
                    new RSAParameters()
                    {
                        //  Modulus = TextEncodings.Base64Url.Decode(mod),
                        //Modulus = FromBase64Url(_conneXionsRsapkcs1Modulus),
                        //Exponent = FromBase64Url(_conneXionsRsapkcs1Exponent)
                        Modulus = GlobalInfo.Security.ConneXionsRsapkcs1Modulus,
                        Exponent = GlobalInfo.Security.ConneXionsRsapkcs1Exponent
                    });

                var sha256 = SHA256.Create();
                var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(tokenParts[0] + '.' + tokenParts[1]));

                var rsaDeformatter = new RSAPKCS1SignatureDeformatter(rsa);
                rsaDeformatter.SetHashAlgorithm("SHA256");

                var result = rsaDeformatter.VerifySignature(hash, GenericFunc.FromBase64Url(tokenParts[2]));

                if (result)
                    outToken = new JwtSecurityToken(tokenStr);

                return result;

            }
            catch (Exception e)
            {
                //CxLog.Error(_tag, _source, "Error while validating JWT at: " + GlobalInfo.SystemName + ": " + token, e);
                ex = new Exception("Error while validating Default JWT at: " + GlobalInfo.SystemName + ": " + token, e);
                return false;
            }
        }

        public static bool isValidJWTAzureAD(string token, string endpoint, out JwtSecurityToken outToken, out Exception ex)
        {

            outToken = null;
            ex = null;

            try
            {                

                if (string.IsNullOrEmpty(endpoint))
                {
                    ex = new Exception("Error while validating AAD JWT at: " + GlobalInfo.SystemName + ": The received provider endpoint is null or empty");
                    return false;
                }

                ConfigurationManager<OpenIdConnectConfiguration> configManager =
                    new ConfigurationManager<OpenIdConnectConfiguration>(endpoint,
                        new OpenIdConnectConfigurationRetriever());

                OpenIdConnectConfiguration config = configManager.GetConfigurationAsync().Result;

                TokenValidationParameters validationParameters = new TokenValidationParameters
                {
                    //ValidAudience = "api://74024c19-8d12-4e6b-a369-62d6aa49df3d",
                    //ValidIssuer = "https://sts.windows.net/6ee19001-d0c4-45f8-af8b-ff00f16d07e1/",
                    ValidAudiences = GlobalInfo.Security.ValidAudiences,
                    ValidIssuers = GlobalInfo.Security.ValidIssuers,
                    ValidateAudience = true,
                    ValidateIssuer = true,
                    IssuerSigningKeys = config.SigningKeys,
                    ValidateLifetime = true
                };

                JwtSecurityTokenHandler tokendHandler = new JwtSecurityTokenHandler();

                SecurityToken jwt;

                var result = tokendHandler.ValidateToken(token, validationParameters, out jwt);

                outToken = jwt as JwtSecurityToken;

                return (result != null && jwt != null);
            }
            catch (Exception e)
            {
                //CxLog.Error(_tag, _source, "Error while validating AAD JWT at: " + GlobalInfo.SystemName + ": " + token, e);
                ex = new Exception("Error while validating AAD JWT at: " + GlobalInfo.SystemName + ": " + token, e);
                return false;
            }
        }

        private static string JwtDecrypt(string cipherData)
        {
            //if (_conneXionsKey == null || _conneXionsKey.Length == 0)
            //    _conneXionsKey = Convert.FromBase64String(ConfigurationManager.AppSettings["JWT_KEY"]);

            //if (string.IsNullOrEmpty(_conneXionsPwd))
            //    _conneXionsPwd = ConfigurationManager.AppSettings["JWT_KEY_PWD"];

            //var certificate = new X509Certificate2(_conneXionsKey, _conneXionsPwd, X509KeyStorageFlags.Exportable | X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet);
            //using (certificate.GetRSAPrivateKey()) { }

            //var privateKey = certificate.PrivateKey as RSACryptoServiceProvider;

            //return Jose.JWT.Decode(cipherData, privateKey);
            return Jose.JWT.Decode(cipherData, GlobalInfo.Security.PrivateKey);
        }

        #endregion JWT Auth validation methods

        //protected static byte[] FromBase64Url(string base64Url)
        //{
        //    string padded = base64Url.Length % 4 == 0
        //        ? base64Url : base64Url + "====".Substring(base64Url.Length % 4);
        //    string base64 = padded.Replace("_", "/")
        //                          .Replace("-", "+");
        //    return Convert.FromBase64String(base64);
        //}


        #region Identity Validations

        private bool OnAuthorizeBearerUser(string user, string pass)
        {

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
                return false;

            return true;
        }

        private bool OnAuthorizeBasicUser(BasicAuthenticationIdentity identity, HttpRequestMessage request)
        {
            if (string.IsNullOrEmpty(identity.Name) || string.IsNullOrEmpty(identity.Password))
                return false;

            return request.Headers.Authorization.Parameter == GlobalInfo.Security.BasicAutentication;
        }

        //private HttpResponseMessage Forbidden(HttpRequestMessage request)
        //{
        //    return new HttpResponseMessage(HttpStatusCode.Forbidden);
        //}

        #endregion Identity Validations

        #region Basic Authentication Validations

        private bool AuthorizedConnection(ApiPath path)
        {
            //var enabled = bool.Parse(ConfigurationManager.AppSettings["IP_FILTER_ENABLED"]);
            //ApiPath path = request.GetRouteData().Route.Defaults[ApiEngine._apiPath] as ApiPath;

            if (path.isIPFilterDisabled)
                return true;

            if (!GlobalInfo.Security.isIPFilterEnabled)
                return true;

            var caller = GetCallerIP();

            if (caller == null)
                return false;

            var result = false;

            foreach (var iprange in GetAllowedIPs())
            {
                if (iprange.IsInRange(caller))
                {
                    result = true;
                }
            }

            if (!result)
                CxLog.Error("BAT", "BasicAuthFilter", new Exception("Client IP Not Allowed: " + caller + ", url requested: " + HttpContext.Current.Request.Url.AbsolutePath));

            return result;
        }            

        private IEnumerable<IpAddressRange> GetAllowedIPs()
        {
            return GlobalInfo.Security.AllowedIPs;
        }

        private IPAddress GetCallerIP()
        {
            var request = HttpContext.Current.Request;
            var serverVariablesHttpXForwardedFor = request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            var serverVariablesRemoteAddr = request.ServerVariables["REMOTE_ADDR"];
            var remoteIp = request.UserHostAddress;
            var ip = "127.0.0.1";
            if (!string.IsNullOrEmpty(serverVariablesHttpXForwardedFor) &&
                !serverVariablesHttpXForwardedFor.ToLower().Contains("unknown"))
            {
                serverVariablesHttpXForwardedFor = serverVariablesHttpXForwardedFor.Trim();

                string[] ipRange = serverVariablesHttpXForwardedFor.Split(',');

                if (ipRange[0].Count(x => x.Equals(':')) == 1)
                {
                    ipRange = ipRange[0].Split(':');
                }
                
                //if (ipRange[0].Contains(":"))
                //    ipRange = ipRange[0].Split(':');

                ip = ipRange[0];
            }
            else if (!string.IsNullOrEmpty(remoteIp))
            {
                if (!request.IsLocal)
                    ip = remoteIp;
            }
            else if (!string.IsNullOrEmpty(serverVariablesRemoteAddr))
            {
                if (!request.IsLocal)
                {
                    serverVariablesRemoteAddr = serverVariablesRemoteAddr.Trim();
                    ip = serverVariablesRemoteAddr;
                }
            }

            IPAddress ipa;

            if (!IPAddress.TryParse(ip, out ipa))
            {
                CxLog.Error("BAT", "BasicAuthFilter", new Exception("Client IP cannot be parsed: '" + ip + "' at " + GlobalInfo.SystemName + ", url requested: " + HttpContext.Current.Request.Url.AbsolutePath));
            }
            
            return ipa;
        }

        #endregion Basic Authentication Validations

    }

    public class BasicAuthenticationIdentity : GenericIdentity
    {
        public BasicAuthenticationIdentity(string name, string password)
            : base(name, "Basic")
        {
            Password = password;
        }

        /// <summary>
        /// Basic Auth Password for custom authentication
        /// </summary>
        public string Password { get; set; }

        public bool Equals(BasicAuthenticationIdentity obj)
        {
            return Password == obj.Password &&
                   Name == obj.Name;
        }
    }
}