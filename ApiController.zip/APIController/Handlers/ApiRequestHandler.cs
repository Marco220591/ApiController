﻿//using APIController.Models.Core;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net.Http;
//using System.Threading;
//using System.Threading.Tasks;
//using System.Reflection;
//using System.Net;
//using System.Web.Http;
//using System.Web.Http.Routing;
//using System.Web;
//using CxUtilities.Web.Http;
//using CxUtilities.DataConection;
//using CxUtilities.Logger;
//using CxUtilities;

//namespace APIController.Handlers
//{
//    public class ApiRequestHandler : DelegatingHandler
//    {
//        internal const string connectionKey = "{2B0DDFC0-5943-47B6-BA33-1BCE8C7B3635}";
//        internal const string _ApiControllerTag = "ACD";
//        internal const string _ApiControllerSource = "APIController";

//        public PathApiData ApiData { get; }

//        public ApiRequestHandler(PathApiData apiData) { ApiData = apiData; }

//        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
//        {
//            Type apiClass;
//            Task<HttpResponseMessage> execTask = null;
//            System.Web.Http.Controllers.HttpControllerDescriptor descriptor;
//            string errorMsg;

//            if (!ApiData.GetHandlerData(out apiClass, out descriptor, out errorMsg))
//            {
//                string message = $"{ApiData.Api.URLPath} not found:\r\n\r\n{errorMsg}";
//                var ex = new NotImplementedException(message);
//                CxLog.Error(_ApiControllerTag, _ApiControllerSource, ex);
//                throw ex;
//            }

//            using (var obj = Activator.CreateInstance(apiClass) as ApiController)
//            {
//                obj.RequestContext = request.GetRequestContext();
//                obj.Request = request;
//                obj.Url = request.GetUrlHelper();
//                obj.User = HttpContext.Current.User;

//                var cc = new System.Web.Http.Controllers.HttpControllerContext();
//                cc.Configuration = request.GetConfiguration();
//                cc.ControllerDescriptor = descriptor;
//                cc.Controller = obj;
//                cc.RequestContext = obj.RequestContext;
//                cc.Request = request;
//                cc.RouteData = request.GetRouteData();                

//                var outParameters = ApiData.Api.References.Where(r => r.IO == "O").ToDictionary(r => r.Parameter.ParameterName, r => r.Parameter.ParameterDescription as object);

//                var inParameters = ApiData.Api.References.Where(r => r.IO == "I").ToDictionary(r => r.Parameter.ParameterName, r => r.Parameter.ParameterDescription as object);

//                try
//                {
//                    obj.GetType().GetMethod("SetParameters", new Type[] { typeof(IDictionary<string, object>), typeof(IDictionary<string, object>), typeof(string) })?.Invoke(obj, new object[] { outParameters, inParameters, connectionKey });
//                    execTask = obj.ExecuteAsync(cc, cancellationToken);
//                }
//                catch (HttpResponseException ex)
//                {
//                    var exAux = new ApplicationException($"{ApiData.Api.URLPath} -- {ApiData.Api.FQClassName} -- {ApiData.Api.ClassMethod}", ex);
//                    if (ex.Response.StatusCode == HttpStatusCode.NotFound)
//                    {
//                        var message = "No action was found on the controller";
//                        var notFoundError = ((ex.Response.Content as ObjectContent<HttpError>)?.Value as HttpError)?.FirstOrDefault(e => e.Value?.ToString()?.Contains(message) == true);
//                        if (notFoundError != null)
//                            exAux = new ApplicationException($"{ApiData.Api.URLPath} -- {Convert.ToString(notFoundError.Value)} -- {ApiData.Api.ClassMethod}", ex);
//                    }
//                    CxLog.Error(_ApiControllerTag, _ApiControllerSource, exAux);
//                    throw exAux;
//                }
//                catch (System.Exception ex)
//                {
//                    var exAux = new ApplicationException($"{ApiData.Api.URLPath} -- {ApiData.Api.FQClassName} -- {ApiData.Api.ClassMethod}", ex);
//                    CxLog.Error(_ApiControllerTag, _ApiControllerSource, exAux);
//                    throw exAux;
//                }
//                cc = null;
//                apiClass = null;
//                descriptor = null;
//            }
//            return await execTask;
//        }
//    }
//}