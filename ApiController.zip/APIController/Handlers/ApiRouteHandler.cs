﻿using APIController.Models.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Reflection;
using System.Net;
using System.Web.Http;
using CxUtilities.Logger;
using APIController.Core;
using System.Web.Http.Dispatcher;
using System.Web.Http.Controllers;
using static APIController.Core.TypeActivator;
using CxInterfaces.Web.Http;

namespace APIController.Handlers
{
    public class ApiRouteHandler : DelegatingHandler
    {
        internal const string connectionKey = "{2B0DDFC0-5943-47B6-BA33-1BCE8C7B3635}";
        private ApiEngine _apiEngineRef;
        private HttpConfiguration _configRef;
        private static readonly string _methodSetParam = "SetParameters";
        private static readonly string _UrlNotFound = " not Found!";
        private static readonly string _NoDllLoaded = "No dll was loaded for: ";
        private static readonly string _UnableToLoad = "Dll could not be loaded for: ";
        private static readonly string _NoControllerFound = "No controller was found on the assembly for: ";
        private static readonly string _NoActionFound = "No action was found on the controller";
        private static readonly string _NotSupportedController = "No supported controller was found on the assembly for: ";
        private static readonly string _sep = " -- ";

        public ApiRouteHandler(ApiEngine instanceRef, HttpConfiguration config) {

            _apiEngineRef = instanceRef;
            _configRef = config;
            InnerHandler = new HttpControllerDispatcher(config);
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {            
            Task<HttpResponseMessage> execTask;                       
            ApiPath path = request.GetRouteData().Route.Defaults[ApiEngine._apiPath] as ApiPath;
            //ApiPath auxPath = _apiEngineRef.GetApiPathByRouteTemplate(request.GetRouteData().Route.RouteTemplate);

            if (path == null)
            {
                throw new NotImplementedException(request.RequestUri.AbsolutePath + _UrlNotFound);
            }

            //in some weird cases were the assemblies resolver could not be triggered, we need to do something
            _apiEngineRef.CheckAssembliesResolver();

            //We check the status of the API

            //Loaded = 100% Working but in some weird cases, by default is loaded but actually it wasnt.
            //NotLoaded = Not fully working, not all operations were loaded.
            //NotExist = The configured assembly was not actually present on the file system.
            //Error = The configured assembly exists on file system but there was an error while loading it
            switch (path.Status)
            {
                case ApiPathStatus.NotExist:
                    throw new DllNotFoundException(_NoDllLoaded + path.ApiCode + _sep + path.URLPath);
                case ApiPathStatus.Error:
                    //Lets try to load the component again.
                    var loaded = _apiEngineRef.SelfHealingFor(path.SourcePath);
                    if (!loaded)
                    {
                        throw new DllNotFoundException(_UnableToLoad + path.ApiCode + _sep + path.URLPath);
                    }
                    break;                
                case ApiPathStatus.NotLoaded:
                    throw new NotImplementedException(_NoControllerFound + path.ApiCode + _sep + path.URLPath + ", Class: " + path.ControllerRef.FQDName + ", Assembly: " + path.SourcePath);
            }

            //Double Check the ControllerRef is there despites the Path Status
            if (path.ControllerRef == null)
            {
                path.Status = ApiPathStatus.Error;
                //Lets try to load the component again.
                var loaded = _apiEngineRef.SelfHealingFor(path.SourcePath);
                if (!loaded || path.ControllerRef == null)
                {
                    throw new DllNotFoundException(_UnableToLoad + path.ApiCode + _sep + path.URLPath);
                }

            }

            //Stopwatch bench = Stopwatch.StartNew();            
            using (var baseController = path.ControllerRef.Activator() as ApiController)
            {
                try
                {

                    //var controller = path.ControllerRef.Descriptor.CreateController(request);
                    //var controller = ((Func<object, object>)path.ControllerRef.ActivatorCont)(null) as ApiController;                      
                    //Func<ApiController> act = TypeActivator.Create<ApiController>(path.ControllerRef.ClassType);
                    //var result = ((Func<object, object>)path.ControllerRef.ActivatorCont)(path.ControllerRef.ClassType) as ApiController;               

                    //Stopwatch mark = Stopwatch.StartNew();
                    //var baseController = path.ControllerRef.Activator() as ApiController;
                    //var baseController = path.ControllerRef.AssemblyRef.DomainRef.CreateInstanceAndUnwrap(path.ControllerRef.AssemblyRef.AssemblyRef.FullName, path.ControllerRef.ClassType.FullName) as ApiController;                    
                    //mark.Stop();
                    //System.Diagnostics.Debug.Print(mark.ElapsedMilliseconds.ToString() + " Controller Activator");

                    if (baseController == null) throw new NotImplementedException(_NotSupportedController + path.ApiCode + _sep + path.URLPath + ", Class: " + path.ControllerRef.FQDName + ", Assembly: " + path.SourcePath);

                    var controller = baseController as IBaseApiController;
                    //if (typeof(IBaseApiController).IsAssignableFrom(path.ControllerRef.ClassType))
                    //if (baseController is IBaseApiController)
                    if (path.ControllerRef.Descriptor == null) path.ControllerRef.CreateControllerDescriptor(_configRef);                    

                    if (controller != null)
                    {
                        //var controller = (IBaseApiController)baseController;
                        //mark = Stopwatch.StartNew();
                        controller.SetParameters(path.PublicParams, path.PrivateParams, connectionKey);
                        //mark.Stop();
                        //System.Diagnostics.Debug.Print(mark.ElapsedMilliseconds.ToString() + " SetParametersDirect");
                        
                        HttpControllerContext cc = new HttpControllerContext(request.GetRequestContext(), request, path.ControllerRef.Descriptor, controller);
                        execTask = controller.ExecuteAsync(cc, cancellationToken);
                    }
                    else
                    {
                        //mark = Stopwatch.StartNew();
                        MethodInfo method = baseController.GetType().GetMethod(_methodSetParam, new[] { typeof(IDictionary<string, object>), typeof(IDictionary<string, object>), typeof(string) });
                        SetParametersDelegate action = (SetParametersDelegate)Delegate.CreateDelegate(typeof(SetParametersDelegate), baseController, method);
                        action.Invoke(path.PublicParams, path.PrivateParams, connectionKey);
                        //mark.Stop();
                        //System.Diagnostics.Debug.Print(bench.ElapsedMilliseconds.ToString() + " SetParametersDelegate");

                        HttpControllerContext cc = new HttpControllerContext(request.GetRequestContext(), request, path.ControllerRef.Descriptor, baseController);
                        execTask = baseController.ExecuteAsync(cc, cancellationToken);
                    }

                }
                catch (HttpResponseException ex)
                {
                    var exAux = new ApplicationException(path.ApiCode + _sep + path.URLPath + _sep + path.FQClassName + _sep + path.ClassMethod, ex);
                    if (ex.Response.StatusCode == HttpStatusCode.NotFound)
                    {                        
                        var notFoundError = ((ex.Response.Content as ObjectContent<HttpError>)?.Value as HttpError)?.FirstOrDefault(e => e.Value?.ToString().Contains(_NoActionFound) == true);
                        if (notFoundError != null)
                            exAux = new ApplicationException(path.ApiCode + _sep + path.URLPath + _sep + Convert.ToString(notFoundError.Value) + _sep + path.ClassMethod, ex);
                    }
                    CxLog.Error(ApiEngine._tag, ApiEngine._source, exAux);
                    throw exAux;
                }
                catch (Exception ex)
                {
                    var exAux = new ApplicationException(path.ApiCode + _sep + path.URLPath + _sep + path.FQClassName + _sep + path.ClassMethod, ex);
                    CxLog.Error(ApiEngine._tag, ApiEngine._source, exAux);
                    throw exAux;
                }
            }

            //bench.Stop();
            //System.Diagnostics.Debug.Print(bench.ElapsedMilliseconds.ToString() + " using statement time");

            return await execTask;
        }
    }
}