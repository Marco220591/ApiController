﻿//using CxUtilities.DataConection;
//using System.Data.Common;
//using System.Net.Http;
//using System.Threading;
//using System.Threading.Tasks;
//using System.Web;
//using APIController.Models.Core;
//using System.Net;
//using APIController.Core;
//using System;
//using CxUtilities.Exceptions;
//using System.Net.Http.Formatting;
//using System.Web.Http;
//using CxUtilities;


//namespace APIController.Handlers
//{
//    public class RequestHandler : DelegatingHandler
//    {        
//        private DbConnection _con;
//        private string _jsData = "";
//        private MediaTypeFormatter _formatter;

//        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
//        {
//            //var context = ((HttpContextBase)request.Properties["MS_HttpContext"]);
//            //var jsSettings = context.Request.Params.GetValues("Settings");
//            //var jsSecuriry = context.Request.Params.GetValues("ApiSecurity");
//            _formatter = GlobalConfiguration.Configuration.Formatters.JsonFormatter;

//            HttpResponseMessage res;
//            try
//            {
//                //var usr = new UserToken(request);

//                var api = GetApiInformation(request);
//                var apiProcess = _jsData != null ? new ApiProcess(api, _jsData, request) : new ApiProcess(api);
//                //res = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(apiProcess.Invoke()) };
//                res = request.CreateResponse(HttpStatusCode.OK, apiProcess.Invoke(), _formatter);
//            }
//            catch (Exception e)
//            {
//                throw new DataServiceException(e.Message, e);
//            }

//            var tsc = new TaskCompletionSource<HttpResponseMessage>();
//            tsc.SetResult(res);
//            return tsc.Task;
//        }

//        public ApiReference GetApiInformation(HttpRequestMessage request)
//        {
//            var api0 = new PathApiData(null); // request);
//            _con = CxConnection.CreateDbConnectionByName(GlobalInfo.ConnectionName);
//            _con.Open();
//            var api = (ApiReference)null; // api0.GetData(_con);
//            if (api == null) throw new Exception("API Path not found!");
//            api.SourcePath = HttpContext.Current.Server.MapPath(GlobalInfo.AssemblyDirectory + api.SourcePath);
//            return api;

//            //var res = new HttpResponseMessage(HttpStatusCode.NotFound) { Content = new StringContent("Path not found!") };
//            //var tsc = new TaskCompletionSource<HttpResponseMessage>();
//            //tsc.SetResult(res);
//            //  return tsc.Task;
//        }
//    }
    
//}