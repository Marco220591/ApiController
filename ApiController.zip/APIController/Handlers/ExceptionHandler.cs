﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using CxUtilities.Logger;
using Microsoft.ApplicationInsights;
using APIController.Core;
using APIController.Core.Constants;
using APIController.Models.Core;
using CxUtilities.Exceptions;
using CxInterfaces.Exceptions;

namespace APIController.Handlers
{
    public class ExceptionHandler
    {

        private static TelemetryClient _telemetry;
        private static string _referenceNotFound = "No Reference Found";

        private static HttpResponseMessage GetResponseByError(string reasonCode, string moreInformation = "", string httpMessage = ErrorDto.Error500Desc, string httpCode = ErrorDto.Error500) => GetResponseByError(new ErrorDto(reasonCode, moreInformation, httpMessage, httpCode));

        private static HttpResponseMessage GetResponseByError(IErrorDto error)
        {            
            HttpStatusCode httpCode;            

            if (!Enum.TryParse(error.HttpCode, out httpCode))
            {
                httpCode = HttpStatusCode.InternalServerError;
                error.HttpMessage = ErrorDto.Error500Desc;
            }

            return new HttpResponseMessage(httpCode)
            {
                Content = new PushStreamContent((stream, content, ctx) => {
                    var serializer = new JsonSerializer();
                    using (var writer = new StreamWriter(stream))
                    {
                        serializer.Serialize(writer, error);
                        stream.Flush();
                    }
                })
                //,ReasonPhrase = HttpStatusDescription //error.HttpMessage
            };
        }

        public static HttpResponseMessage OnException(Exception exCause)
        {
            HttpResponseMessage resp = null;
            IErrorDto error;

            IBaseApiException baseEx = exCause as IBaseApiException;
            IBaseApiException innerEx = exCause.InnerException as IBaseApiException;

            if (baseEx == null)
            {
                string code = "";

                if (exCause.Message.Contains("|"))
                {
                    var messageSplit = exCause.Message.Split('|');
                    code = messageSplit.Length > 1 ? messageSplit[0] : "";
                }
                else
                {
                    code = exCause.Message;
                }

                switch (code)
                {
                    case "2013":
                        error = new ErrorDto("2013");
                        //moreInformation = "User already exist in the database"
                        break;
                    case "2014":
                        error = new ErrorDto("2014");
                        //moreInformation = "User does not have authorization for create or modify users"
                        break;
                    case "2007":
                        error = new ErrorDto("2007");
                        //moreInformation = "customer number not found"
                        break;
                    case "2008":
                        error = new ErrorDto("2008");
                        //moreInformation = "customer email was not found or does not exist"
                        break;
                    case "2010":
                        error = new ErrorDto("2010");
                        //moreInformation = "this customer has a power user created"
                        break;
                    case "2011":
                        error = new ErrorDto("2011");
                        //moreInformation = "Error to save or modify Database"
                        break;
                    case "2012":
                        error = new ErrorDto("2012");
                        //moreInformation = "Error Deleting Database"
                        break;
                    default:
                        error = new ErrorDto("2002");                       
                        break;
                }                

                Type exType = exCause.GetType();

                string exClass = exType != null ? exType.FullName : null;

                if (exClass != null)
                {
                    if (exClass.Contains("DataServiceException"))
                    {
                        CxLog.Log(exCause.Message, "DSE", "", "DataService Except.", exCause);
                    }
                    else if (exClass.Contains("AccessReqValidationException"))
                    {
                        CxLog.Log(exCause.Message, "ARE", "", "Access Req Except.", exCause);
                    }
                    else if (exClass.Contains("DataBaseException"))
                    {
                        CxLog.Log(exCause.Message, "DBE", "", "Database Exception", exCause);
                    }
                    else if (exClass.Contains("BackendException"))
                    {
                        CxLog.Log(exCause.Message, "BKD", "", "Backend Exception", exCause);
                    }
                    else if (exCause is NotImplementedException || exCause is DllNotFoundException)
                    {
                        CxLog.Log(exCause.Message, "GBL", "", "Resource does not exist or it is not available", exCause);
                        error = new ErrorDto(ReasonMessage.NotFound.Code, ReasonMessage.NotFound.Description, "Not Found", HttpCodes.NotFound);
                    }
                    else
                    {
                        CxLog.Log(exCause.Message, "GBL", "", "Unknown Exception", exCause);
                    }
                }
                else
                {
                    CxLog.Log(exCause.Message, "GBL", "", "Unknown Exception", exCause);
                }

                resp = GetResponseByError(error);
            }
            else
            {
                resp = GetResponseByError(baseEx.GetCause());
                
                if (baseEx is IDataServiceException)
                {
                    CxLog.Log(exCause.Message, "DSE", "", "DataService Except.", exCause);
                }
                else if (baseEx is IAccessReqValidationException)
                {
                    CxLog.Log(exCause.Message, "ARE", "", "Access Req Except.", exCause);
                }
                else if (baseEx is IDatabaseException)
                {
                    CxLog.Log(exCause.Message, "DBE", "", "Database Exception", exCause);
                }
                else if (baseEx is IBusinessException)
                {
                    CxLog.Log(exCause.Message, "BUE", "", "Business Exception", exCause);
                }
                else if (baseEx is IBackendException || baseEx is IBackendServiceException)
                {
                    CxLog.Log(exCause.Message, "BKD", "", "Backend Exception", exCause);
                }
                else if (exCause is IAuthorizationException)
                {
                    CxLog.Log(exCause.Message, "GBL", "", "Authorization Exception", exCause);
                }
                else
                {
                    CxLog.Log(exCause.Message, "GBL", "", "Unknown Exception", exCause);
                }
            }

            if (resp != null)
                resp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");


            ReportException(exCause);

            return resp;
        }

        public static void ReportException(Exception ex)
        {
            if (_telemetry == null)
                _telemetry = new TelemetryClient();

            Dictionary<string, string> props = new Dictionary<string, string>();

            try
            {
                ApiPath path =
                    HttpContext.Current.Request.RequestContext.RouteData.Values[ApiEngine._apiPath] as ApiPath;

                if (path != null)
                {
                    props.Add("APIPathId", path.APIPathId.ToString());
                    props.Add("ApiCode", path.ApiCode);
                    props.Add("HTTPMethod", path.HTTPMethod);
                    props.Add("URLPath", path.URLPath);
                    props.Add("SourcePath", path.SourcePath);
                    props.Add("SourceFQDN", path.SourceFQDN);
                    props.Add("FQClassName", path.FQClassName);
                    props.Add("ClassMethod", path.ClassMethod);
                    props.Add("Assembly", path.ControllerRef?.AssemblyRef?.AssemblyRef?.FullName ?? _referenceNotFound);
                }
            }
            catch (Exception e)
            {
                CxLog.Error(ApiEngine._tag, ApiEngine._source, "Error getting path properties on ExceptionHandler", e);
            }
            
            _telemetry.TrackException(ex, props);
        }

        public static void ManageGlobalException(Exception e, HttpResponse response)
        {
            IErrorDto error = null;

            IBaseApiException baseEx = e as IBaseApiException;
            if (baseEx != null)
                error = baseEx.GetCause();
            else
                error = new ErrorDto("2002");

            try
            {
                var typeE = e.GetType().FullName;
                CxLog.Error(ApiEngine._tag, ApiEngine._source, typeE, e);
            }
            catch (Exception ex) { error.HttpMessage = ex.Message; }

            response.ContentType = "application/json";
            response.StatusCode = (int)HttpStatusCode.InternalServerError;
            response.Write(JsonConvert.SerializeObject(error));
            response.Flush();

            ReportException(e);
        }

        private static Exception GetLastInnerException(Exception ex, Type type)
        {
           var currentException = ex;
            while (currentException != null)
                if (currentException.GetType() == type)
                    return currentException;
                else
                    currentException = currentException.InnerException;
                            
            return currentException;
        }

    }
}