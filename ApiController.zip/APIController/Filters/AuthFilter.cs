﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Net.Http;
//using System.Security.Principal;
//using System.Text;
//using System.Web;
//using System.Web.Http.Controllers;
//using System.Web.Http.Filters;
//using System.Security.Claims;
//using System.Security.Cryptography;
//using System.IdentityModel.Tokens.Jwt;
//using CxUtilities;
//using CxUtilities.Exceptions;
//using System.Security.Cryptography.X509Certificates;
//using System.Configuration;
//using CxUtilities.Logger;

//namespace APIController.Filters
//{
//    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
//    public class AuthFilter : AuthorizationFilterAttribute
//    {
//        private static string TAG = "ATH";
//        private static string SOURCE = "AuthFilter";
//        /// <summary>
//        /// Public default Constructor
//        /// </summary>
//        public AuthFilter()
//        {
//        }

//        private readonly bool _isActive = true;

//        /// <summary>
//        /// parameter isActive explicitly enables/disables this filter.
//        /// </summary>
//        /// <param name="isActive"></param>
//        public AuthFilter(bool isActive)
//        {
//            _isActive = isActive;
//        }

//        /// <summary>
//        /// Checks basic authentication request
//        /// </summary>
//        /// <param name="filterContext"></param>
//        public override void OnAuthorization(HttpActionContext filterContext)
//        {
//            if (!_isActive) return;

//            //bool valAuth = filterContext.Request.RequestUri.AbsolutePath.Contains("testDispatchNotification") ||
//            //               filterContext.Request.RequestUri.AbsolutePath.Contains("RequestAccess");
//            GenericIdentity identity = null;

//            //CXLog.Debug(TAG, SOURCE, "AuthFilter.OnAuthorization > valAuth: " + valAuth);

//            //Switch next line to take the JWT from the request
//            //if (!valAuth) 
//            //{
//            //identity = FetchAuthHeader(filterContext);
//            //}
//            //else
//            //{
//            //Line to hardcode the JWT user data
//      //      identity = FetchAuthHeaderMock(filterContext);                
//            //}

//            //CXLog.Debug(TAG, SOURCE, "AuthFilter.OnAuthorization > identity: " + identity);
//            try
//            {
//                identity = FetchAuthHeader(filterContext);

//                if (identity == null)
//                {
//                    //identity = FetchAuthHeaderMock(filterContext);
//                    //ChallengeAuthRequest(filterContext);
//                    //if (identity == null)
//                    //CXLog.Debug(TAG, SOURCE, "AuthFilter.OnAuthorization > ChallengeAuthRequest return;");

//                    //return;
//                    throw new Exception("Unauthorized");
//                }

//                //var genericPrincipal = new GenericPrincipal(identity, null);
//                //HttpContext.Current.User = genericPrincipal;

//                HttpContext.Current.User = new ClaimsPrincipal(identity);

//                if (!OnAuthorizeUser(identity.Name, identity.AuthenticationType, filterContext))
//                {
//                    //ChallengeAuthRequest(filterContext);
//                    throw new Exception("Unauthorized");
//                    //return;
//                }
//                base.OnAuthorization(filterContext);
//            }
//            catch (Exception e)
//            {
//                CxLog.Error(TAG, SOURCE, e);
//                throw new JwtException("OnAuthorization Error", e);
//            }
//        }

//        /// <summary>
//        /// Virtual method.Can be overriden with the custom Authorization.
//        /// </summary>
//        /// <param name="user"></param>
//        /// <param name="pass"></param>
//        /// <param name="filterContext"></param>
//        /// <returns></returns>
//        protected virtual bool OnAuthorizeUser(string user, string pass, HttpActionContext filterContext)
//        {
//            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
//                return false;
//            return true;
//        }

//        void Forbidden(HttpActionContext actionContext)
//        {
//            actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Forbidden);
//        }

//        private bool AuthorizedConnection(HttpActionContext ctx)
//        {
            
//            var enabled = Boolean.Parse(ConfigurationManager.AppSettings["DOMAIN_FILTER_ENABLED"].ToString());
//            var domains = ConfigurationManager.AppSettings["ALLOWED_DOMAINS"].ToString();
//            var origin = System.Web.HttpContext.Current.Request.UserHostName;
//            var result = false;

//            CxLog.Debug(TAG, SOURCE, "Client Domain: " + origin);

//            if (!enabled || string.IsNullOrEmpty(domains))
//            return true;

//            if (enabled && domains.ToUpper().Contains(origin.ToUpper()))
//            result = true;
//            else
//            result = false;
            
//            if (!result)
//            CxLog.Error(TAG, SOURCE, new Exception("Client Domain Not Allowed: " + origin));

//            return result;


//        }

//        /// <summary>
//        /// Checks for authorization header in the request and parses it, creates user credentials and returns as BasicAuthenticationIdentity
//        /// </summary>
//        /// <param name="filterContext"></param>
//        protected virtual GenericIdentity FetchAuthHeader(HttpActionContext filterContext)
//        {

//            string authHeaderValue = null;
//            var localeHeader = filterContext.Request.Headers.AcceptLanguage.DefaultIfEmpty(null).FirstOrDefault();            
//            var appCodeHeader = "App-Code";
//            var appPushHeader = "bm-env";
//            var appPushEnv = "";
//            var appCode = "";

//            //CXLog.Debug(TAG, SOURCE, "AuthFilter.FetchAuthHeader > localeHeader: " + localeHeader);

//            if (filterContext.Request.Headers.Contains(appPushHeader))
//            {
//                appPushEnv = filterContext.Request.Headers.GetValues(appPushHeader).DefaultIfEmpty(null).FirstOrDefault();
//            }

//            if (filterContext.Request.Headers.Contains(appCodeHeader))
//            {
//                appCode = filterContext.Request.Headers.GetValues(appCodeHeader).DefaultIfEmpty(null).FirstOrDefault();                
//            }

//            var locale = localeHeader != null ? localeHeader.Value : null;

//            //CXLog.Debug(TAG, SOURCE, "AuthFilter.FetchAuthHeader > Accept-Language: " + locale);
//            //CXLog.Debug(TAG, SOURCE, "AuthFilter.FetchAuthHeader > " + appCodeHeader + ": " + appCode);

//            var authRequest = filterContext.Request.Headers.Authorization;

//            //CXLog.Debug(TAG, SOURCE, "AuthFilter.FetchAuthHeader > authRequest: " + (authRequest != null ? authRequest.ToString() : "null"));

//            if (authRequest != null && !String.IsNullOrEmpty(authRequest.Scheme) && authRequest.Scheme == "Bearer")
//            {
//                authHeaderValue = authRequest.Parameter;
//                //CXLog.Debug(TAG, SOURCE, "AuthFilter.FetchAuthHeader > authHeaderValue: " + authHeaderValue);
//            }

//            if (string.IsNullOrEmpty(authHeaderValue))
//            {
//                //CXLog.Debug(TAG, SOURCE, "AuthFilter.FetchAuthHeader > authHeaderValue is null or empty > authRequest: " + ((authRequest != null) ? JsonConvert.SerializeObject(authRequest) : ""));
//                return null;
//            }

//            string tokenJWT = null;

//            if (!IsValidRSASignature(authHeaderValue, out tokenJWT))
//            {
//                //CXLog.Debug(TAG, SOURCE, "AuthFilter.FetchAuthHeader > authHeaderValue is not valid > " + authHeaderValue);
//                return null;
//            }

//            JwtSecurityToken JWT = null;
//            GenericIdentity identity = null;                        
//            IDictionary<string, object> claims = null;

//            try
//            {
//                JWT = new JwtSecurityToken(tokenJWT);
//                claims = (Dictionary<string, object>)JWT.Payload;
//                var user = claims["userprincipalname"].ToString();

//                identity = new GenericIdentity(user, "Bearer");
//                foreach (var claim in claims)
//                {
//                    identity.AddClaim(new Claim(claim.Key, claim.Value.ToString()));
//                }
                
//                if (locale != null) identity.AddClaim(new Claim("locale", locale));
//                if (appCode != null) identity.AddClaim(new Claim("appcode", appCode));
//                if (appPushEnv != null) identity.AddClaim(new Claim("appenv", appPushEnv));

//                //CXLog.Log(new Exception("Success in JWT > JWT.rawData: " + JWT.RawData));
//                //CXLog.Log(new Exception("Success in JWT > JWT.rawHeader: " + JWT.RawHeader));
//                //CXLog.Log(new Exception("Success in JWT > JWT.rawPayload: " + JWT.RawPayload));
//                //CXLog.Log(new Exception("Success in JWT > JWT.payload: " + JsonConvert.SerializeObject(JWT.Payload)));
//                //CXLog.Log(new Exception("Success in JWT > JWT.payload.values: " + JsonConvert.SerializeObject(JWT.Payload.Values)));
//                //CXLog.Log(new Exception("Success in JWT > Dic claims: " + JsonConvert.SerializeObject(claims)));
//                //CXLog.Log(new Exception("Success in JWT > accept-language: " + locale + ", " + appCodeHeader + ": " + appCode));
//            }
//            catch (Exception e)
//            {
//                CxLog.Error(TAG, SOURCE, e);
//                //CXLog.Debug(TAG, SOURCE, "Error in JWT > JWT.rawData: " + JWT.RawData);
//                //CXLog.Debug(TAG, SOURCE, "Error in JWT > JWT.rawHeader: " + JWT.RawHeader);
//                //CXLog.Debug(TAG, SOURCE, "Error in JWT > JWT.rawPayload: " + JWT.RawPayload);
//                //CXLog.Debug(TAG, SOURCE, "Error in JWT > JWT.payload: " + JsonConvert.SerializeObject(JWT.Payload));
//                //CXLog.Debug(TAG, SOURCE, "Error in JWT > JWT.payload.values: " + JsonConvert.SerializeObject(JWT.Payload.Values));
//                //CXLog.Debug(TAG, SOURCE, "Error in JWT > Dic claims: " + JsonConvert.SerializeObject(claims));
//                //CXLog.Debug(TAG, SOURCE, "Error in JWT > accept-language: " + locale + ", " + appCodeHeader + ": " + appCode);

//                return null;
//            }

//            return identity;

//        }

//        /// <summary>
//        /// Generates fake claims to create user credentials and returns as BasicAuthenticationIdentity
//        /// </summary>
//        /// <param name="filterContext"></param>
//        protected virtual GenericIdentity FetchAuthHeaderMock(HttpActionContext filterContext)
//        {
//            GenericIdentity identity = null;

//            try
//            {
//                IDictionary<string, object> claims = new Dictionary<string, object>();
//                //claims.Add("guid", "e8cfcc2fe77f410aa6be38db0d636928");
//                claims.Add("countrycode", "52");
//                claims.Add("displayname", "Guillermo Salinas Sangines");
//                //claims.Add("userprincipalname", "michael.jordan@hotmail.com");
//                claims.Add("userprincipalname", "brad.pitt@hotmail.com"); //*/"f-vpaz");
//                claims.Add("uri", "/oic_rest/rest/ldsUserProfile/people/e-gsalinass");
//                claims.Add("telephonenumber", "88885001");
//                claims.Add("mail", "e-gsalinas@neoris.com");
//                claims.Add("appcode", "Foreman_App");
//                claims.Add("locale", "en-MX");
//                claims.Add("appenv", "d");

//                //claims.Add("countrycode", "52");
//                //claims.Add("displayname", "Son Goku");
//                //claims.Add("userprincipalname", "goku@cemex.com");
//                //claims.Add("uri", "/oic_rest/rest/ldsUserProfile/people/e-gsalinass");
//                //claims.Add("telephonenumber", "88885001");
//                //claims.Add("mail", "goku@cemex.com");
//                //claims.Add("appcode", "UserMgmt_App");
//                //claims.Add("locale", "es-MX");

//                var user = claims["userprincipalname"].ToString();

//                identity = new GenericIdentity(user, "Bearer");
//                foreach (var claim in claims)
//                {
//                    identity.AddClaim(new Claim(claim.Key, claim.Value.ToString()));
//                }
//            }
//            catch (Exception)
//            {
//                return null;
//            }

//            return identity;
//        }

//        private static byte[] FromBase64Url(string base64Url)
//        {
//            var padded = base64Url.Length % 4 == 0
//                ? base64Url : base64Url + "====".Substring(base64Url.Length % 4);
//            var base64 = padded.Replace("_", "/")
//                                  .Replace("-", "+");
//            return Convert.FromBase64String(base64);
//        }

//        /// <summary>
//        /// Send the Authentication Challenge request
//        /// </summary>
//        /// <param name="filterContext"></param>
//        private static void ChallengeAuthRequest(HttpActionContext filterContext)
//        {
//            var dnsHost = filterContext.Request.RequestUri.DnsSafeHost;
//            filterContext.Response = filterContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
//            filterContext.Response.Headers.Add("WWW-Authenticate", string.Format("Basic realm=\"{0}\"", dnsHost));
//        }

//        private static string ConneXionsRSAPKCS1MODULUS;
//        private static string ConneXionsRSAPKCS1EXPONENT;
//        private static byte[] ConneXionsKEY;
//        private static string ConneXionsPWD;

//        private static bool IsValidRSASignature(string token, out string tokenStr)
//        {
//            tokenStr = null;

//            if (String.IsNullOrEmpty(ConneXionsRSAPKCS1MODULUS))
//                ConneXionsRSAPKCS1MODULUS = System.Configuration.ConfigurationManager.AppSettings["RSAPKCS1MODULUS"]; //"01XIfjOr6tB-FVm5VkH82PTtpFtEsI3M0nmIDWixLKddtl8JpFFQfKq3ImlumDt0-sXvC4ccDcsGgxwxE99I5Zsga08Vdl5SYISgTg3aN_MLr8cbAq8HLOVJJUjlHAS_SoYcSqAN_h8w-mhUsDtAi2SMms8og7o17xOa7QRQ5uGDAnfTRw-aiLho3904IwY4l4fvNbBu_Kv3OpoEhNfGCJH4htpsnPMb-tXduZiH30I5LiSTKuyYcSgbDZFyQAJJWFG5KiewgdpsU9kMjEYlegNoS7jBRpaa_o5Nk9u7ArMVbB1BEo2eg1Q3Pj9XRvmf22_xYkjRDFl5tYjlnMPV9w";
//            if (String.IsNullOrEmpty(ConneXionsRSAPKCS1EXPONENT))
//                ConneXionsRSAPKCS1EXPONENT = System.Configuration.ConfigurationManager.AppSettings["RSAPKCS1EXPONENT"]; //"AQAB";

//            var JWTDecryptEnabled = Boolean.Parse(System.Configuration.ConfigurationManager.AppSettings["JWT_DECRYPT"].ToString());

//            if (JWTDecryptEnabled)
//            {
//                tokenStr = JWTDecrypt(token);
//            }
//            else
//            {
//                tokenStr = token;
//            }

//            string[] tokenParts = tokenStr.Split('.');

//            if (tokenParts.Length < 3)
//                return false;

//            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();

//            rsa.ImportParameters(
//              new RSAParameters()
//              {

//                  Modulus = FromBase64Url(ConneXionsRSAPKCS1MODULUS),
//                  //  Modulus = TextEncodings.Base64Url.Decode(mod),
//                  Exponent = FromBase64Url(ConneXionsRSAPKCS1EXPONENT)
//              });

//            SHA256 sha256 = SHA256.Create();
//            byte[] hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(tokenParts[0] + '.' + tokenParts[1]));

//            RSAPKCS1SignatureDeformatter rsaDeformatter = new RSAPKCS1SignatureDeformatter(rsa);
//            rsaDeformatter.SetHashAlgorithm("SHA256");
//            if (rsaDeformatter.VerifySignature(hash, FromBase64Url(tokenParts[2])))
//                return true;
//            else
//                return false;

//        }

//        public static string JWTDecrypt(string cipherData)
//        {

//            if (ConneXionsKEY == null || ConneXionsKEY.Length == 0)
//                ConneXionsKEY = Convert.FromBase64String(System.Configuration.ConfigurationManager.AppSettings["JWT_KEY"]);

//            if (String.IsNullOrEmpty(ConneXionsPWD))
//                ConneXionsPWD = System.Configuration.ConfigurationManager.AppSettings["JWT_KEY_PWD"];

//            var privateKey = new X509Certificate2(ConneXionsKEY, ConneXionsPWD, X509KeyStorageFlags.Exportable | X509KeyStorageFlags.MachineKeySet).PrivateKey as RSACryptoServiceProvider;

//            return Jose.JWT.Decode(cipherData, privateKey);

//            //if (String.IsNullOrEmpty(ConneXionsKEY))
//            //    ConneXionsKEY = System.Configuration.ConfigurationManager.AppSettings["AES_KEY"];
//            //if (String.IsNullOrEmpty(ConneXionsIV))
//            //    ConneXionsIV = System.Configuration.ConfigurationManager.AppSettings["AES_IV"];

//            //byte[] key = Encoding.UTF8.GetBytes(ConneXionsKEY);
//            //byte[] iv = StringToByteArray(ConneXionsIV);
//            //var token = Convert.FromBase64String(cipherData);            

//            ////using (var ms = new MemoryStream(key))
//            ////{
//            ////    ms.Read(iv, 0, 16);
//            ////}

//            //try
//            //{
//            //    using (Aes aes = new AesManaged())
//            //    {
//            //        aes.BlockSize = 128;
//            //        aes.KeySize = 256;
//            //        aes.Key = key;
//            //        aes.IV = iv;
//            //        aes.Mode = CipherMode.CBC;
//            //        aes.Padding = PaddingMode.None;

//            //        ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

//            //        using (MemoryStream ms = new MemoryStream(token))
//            //        {
//            //            using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
//            //            {
//            //                string decoded = null;

//            //                using (StreamReader sw = new StreamReader(cs))
//            //                {
//            //                    decoded = sw.ReadToEnd();
//            //                    sw.Close();
//            //                }

//            //                cs.Close();

//            //                return decoded;
//            //            }
//            //        }
//            //    }
//            //}
//            //catch (CryptographicException e)
//            //{
//            //    Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
//            //    return null;
//            //}
//        }

//        public static byte[] StringToByteArray(string hex)
//        {
//            return Enumerable.Range(0, hex.Length)
//                             .Where(x => x % 2 == 0)
//                             .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
//                             .ToArray();
//        }

//    }
//}