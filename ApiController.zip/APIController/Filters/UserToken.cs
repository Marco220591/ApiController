﻿//using System.Linq;
//using System.Security.Principal;
//using System.Security.Claims;
//using Newtonsoft.Json;
//using APIController.Handlers;
//using System.Net.Http;
//using System.Threading;

//namespace APIController.Filters
//{
//    public class UserToken
//    {        
//        public string UserAccount { get; set; }

//        public string SamAccountName { get; set; }

//        public string DisplayName { get; set; }

//        public string CountryCode { get; set; }

//        public string Telephone { get; set; }

//        public string Mobile { get; set; }

//        public string Mail { get; set; }

//        public string Uri { get; set; }

//        public string AppCode { get; set; }

//        private string _locale;        

//        public string Locale {
//            get { return _locale; }
//            set {
//                value = value.Replace('-', '_');
//                _locale = (!string.IsNullOrEmpty(value)) ? value : "en_US";
//                SapLanguage = _locale.Split('_')[0].ToUpper();
//                if (!ExistsLocale())
//                    _locale = SapLanguage == "ES" ? "es_MX" : "en_US";
//            }
//        }

//        public string SapLanguage { get; set; }

//        public string AppEnv { get; set; }

//        private IPrincipal User { get; }

//        public UserToken(HttpRequestMessage request)
//        {
//            var authType = AuthorizationHandler.GetAuthenticationType(request);
//            if (authType == "Bearer")
//            {
//                User = request.GetRequestContext().Principal;
//                ParseToken();
//            }
//            else if (authType == "Basic")
//            {
//                User = Thread.CurrentPrincipal;
//            }
//        }

//        private void ParseToken()
//        {
//            UserAccount = User.Identity.Name;
//            SamAccountName = UserAccount;

//            var claims = ((ClaimsPrincipal)User).Claims.ToList();

//            var aux = claims.Find(x => x.Type == "displayname");
//            DisplayName = (aux != null ? aux.Value : "");

//            aux = claims.Find(x => x.Type == "countrycode");
//            CountryCode = (aux != null ? aux.Value : "");

//            aux = claims.Find(x => x.Type == "telephonenumber");
//            Telephone = (aux != null ? aux.Value : "");
//            Mobile = Telephone;

//            aux = claims.Find(x => x.Type == "mail");
//            Mail = (aux != null ? aux.Value : "");

//            aux = claims.Find(x => x.Type == "uri");
//            Uri = (aux != null ? aux.Value : "");

//            aux = claims.Find(x => x.Type == "appcode");
//            AppCode = (aux != null ? aux.Value : "");

//            aux = claims.Find(x => x.Type == "locale");
//            Locale = (aux != null ? aux.Value : "");

//            aux = claims.Find(x => x.Type == "appenv");
//            AppEnv = (aux != null ? aux.Value : "");
//        }

//        public override string ToString()
//        {
//            return JsonConvert.SerializeObject(this);
//        }

//        private bool ExistsLocale()
//        {
//            var result = new Utils.GenericFunc().ExistsLanguage(_locale);
//            return result;
//        }
//    }
//}