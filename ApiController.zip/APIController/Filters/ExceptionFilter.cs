﻿//using CxUtilities.Exceptions;
//using Newtonsoft.Json;
//using System;
//using System.IO;
//using System.Linq;
//using System.Net;
//using System.Net.Http;
//using System.Net.Http.Headers;
//using System.Text;
//using System.Web;
//using System.Web.Http.Filters;
//using APIController.Models.dto;
//using CxUtilities.Logger;

//namespace APIController.Filters
//{
//    public class ExceptionFilter : ExceptionFilterAttribute
//    {
//        public override void OnException(HttpActionExecutedContext context)
//        {
//            if (context.Exception is JwtException)
//            {
//                var error = new Error("2003")
//                {
//                    httpCode = "500",
//                    httpMessage = "Internal Server Error",
//                    reasonCode = "2003",
//                    //moreInformation = "The authentication information was not processed correctly"
//                    moreInformation = ""
//                };

//                var resp = new HttpResponseMessage(HttpStatusCode.InternalServerError)
//                {
//                    Content = new PushStreamContent((stream, content, ctx) => {
//                        var serializer = new JsonSerializer();
//                        using (var writer = new StreamWriter(stream))
//                        {
//                            serializer.Serialize(writer, error);
//                            stream.Flush();
//                        }
//                    }),
//                    ReasonPhrase = "Internal Server Error"
//                };

//                //CXUtilities.CXLog.Log(context.Exception.Message, "JWT", "", "JWT Exception", context.Exception);

//                resp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
//                context.Response = resp;
//            }

//            if (context.Exception is DataServiceException)
//            {
//                Error error;
//                switch (context.Exception.Message)
//                {
//                    case "2013":
//                        error = new Error("2013")
//                        {
//                            httpCode = "500",
//                            httpMessage = "Internal Server Error",
//                            reasonCode = "2013",
//                            //moreInformation = "User already exist in the database"
//                            moreInformation = ""
//                        };
//                        break;
//                    case "2014":
//                        error = new Error("2014")
//                        {
//                            httpCode = "500",
//                            httpMessage = "Internal Server Error",
//                            reasonCode = "2014",
//                            //moreInformation = "User does not have authorization for create or modify users"
//                            moreInformation = ""
//                        };
//                        break;
//                    default:
//                        if(context.Exception.InnerException is BussinessException)
//                            error = new Error("")
//                            {
//                                httpCode = "406",
//                                httpMessage = "Data Entry Error",
//                                reasonCode = "",
//                                moreInformation = context.Exception.InnerException.Message
//                            };
//                        else
//                        {
//                            var exception = GetLastInnerException(
//                                context.Exception, 
//                                typeof(System.Data.Entity.Validation.DbEntityValidationException)
//                                ) as System.Data.Entity.Validation.DbEntityValidationException;
//                            if (exception != null)
//                            {
//                                var sb = new StringBuilder();
//                                if (exception != null)
//                                {

//                                    sb.Append("{ EFErrors : [");
//                                    var eve = exception.EntityValidationErrors.ToArray();
//                                    for (var i = 0; i < eve.Length; i++)
//                                    {
//                                        sb.AppendFormat("{0}", (i == 0 ? "" : ","));
//                                        sb.Append("{");
//                                        sb.AppendFormat(@"""entityClass"" : ""{0}"" , ""errors"" : [",  eve[i].Entry.Entity.ToString());

//                                        var evev = eve[i].ValidationErrors.ToArray();
//                                        for (var j = 0; j < evev.Length; j++)
//                                        {
//                                            sb.AppendFormat("{0}", (j == 0 ? "" : ","));
//                                            sb.Append("{");
//                                            sb.AppendFormat(@"""property"" : ""{0}"", ""error"":""{1}""", evev[j].PropertyName, evev[j].ErrorMessage);
//                                            sb.Append("}");
//                                        }
//                                        sb.Append("]}");
//                                    }
//                                    sb.Append("]}");

//                                }
//                                error = new Error("2002")
//                                {
//                                    httpCode = "500",
//                                    httpMessage = "Internal Server Error",
//                                    reasonCode = "2002",
//                                    moreInformation = "Data Service error from EF -> " + sb.ToString()
//                                };
//                            }
//                            else
//                                error = new Error("2002")
//                            {
//                                httpCode = "500",
//                                httpMessage = "Internal Server Error",
//                                reasonCode = "2002",
//                                moreInformation =  "Data Service error"
//                            };
//                        }
//                        break;
//                }
                
//                var resp = new HttpResponseMessage(HttpStatusCode.InternalServerError)
//                {
//                    Content = new PushStreamContent((stream, content, ctx) => {
//                        var serializer = new JsonSerializer();
//                        using(var writer = new StreamWriter(stream))
//                        {
//                            serializer.Serialize(writer, error);
//                            stream.Flush();
//                        }
//                    }),
//                    ReasonPhrase = "Internal Server Error"
//                };

//                CxLog.Log(context.Exception.Message, "DSE", "", "DataService Except.", context.Exception);

//                resp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
//                context.Response = resp;

//            }

//            if (context.Exception is AccessReqValidationException)
//            {
//                Error error;
//                switch (context.Exception.Message)
//                {
//                    case "2007":
//                        error = new Error("2004")
//                        {
//                            httpCode = "500",
//                            httpMessage = "Internal Server Error",
//                            reasonCode = "2004",
//                            //moreInformation = "customer number not found"
//                            moreInformation = ""
//                        };
//                        break;
//                    case "2008":
//                        error = new Error("2005")
//                        {
//                            httpCode = "500",
//                            httpMessage = "Internal Server Error",
//                            reasonCode = "2005",
//                            //moreInformation = "customer email was not found or does not exist"
//                            moreInformation = ""
//                        };
//                        break;
//                    case "2010":
//                         error = new Error("2006")
//                        {
//                            httpCode = "500",
//                            httpMessage = "Internal Server Error",
//                            reasonCode = "2006",
//                             //moreInformation = "this customer has a power user created"
//                             moreInformation = ""
//                         };
//                        break;
//                    default:
//                        error = new Error("2002")
//                        {
//                            httpCode = "500",
//                            httpMessage = "Internal Server Error",
//                            reasonCode = "2002",
//                            //moreInformation = "Data Service error"
//                            moreInformation = ""
//                        };
//                        break;
//                }
               

//                var resp = new HttpResponseMessage(HttpStatusCode.InternalServerError)
//                {
//                    Content = new PushStreamContent((stream, content, ctx) => {
//                        var serializer = new JsonSerializer();
//                        using (var writer = new StreamWriter(stream))
//                        {
//                            serializer.Serialize(writer, error);
//                            stream.Flush();
//                        }
//                    }),
//                    ReasonPhrase = "Internal Server Error"
//                };

//                CxLog.Log(context.Exception.Message, "ARE", "", "Access Req Except.", context.Exception);

//                resp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
//                context.Response = resp;

//            }

//            if (!(context.Exception is DataBaseException)) return;
//            {
//                Error error;

//                var messageSplit = context.Exception.Message.Split('|');
//                var errorCode = messageSplit.Length > 1 ? messageSplit[0] : "";

//                switch (errorCode)
//                {
//                    case "2011":
//                        error = new Error("2011")
//                        {
//                            httpCode = "500",
//                            httpMessage = "Internal Server Error",
//                            reasonCode = "2011",
//                            //moreInformation = "Error to save or modify Database"
//                            moreInformation = ""
//                        };
//                        break;
//                    case "2012":
//                        error = new Error("2012")
//                        {
//                            httpCode = "500",
//                            httpMessage = "Internal Server Error",
//                            reasonCode = "2012",
//                            //moreInformation = "Error Deleting Database"
//                            moreInformation = ""
//                        };
//                        break;
//                    default:
//                        error = new Error("2002")
//                        {
//                            httpCode = "500",
//                            httpMessage = "Internal Server Error",
//                            reasonCode = "2002",
//                            //moreInformation = "Data Service error"
//                            moreInformation = ""
//                        };
//                        break;
//                }

//                var resp = new HttpResponseMessage(HttpStatusCode.InternalServerError)
//                {
//                    Content = new PushStreamContent((stream, content, ctx) => {
//                        var serializer = new JsonSerializer();
//                        using (var writer = new StreamWriter(stream))
//                        {
//                            serializer.Serialize(writer, error);
//                            stream.Flush();
//                        }
//                    }),
//                    ReasonPhrase = "Internal Server Error"
//                };

//                CxLog.Log(context.Exception.Message, "DBE", "", "Database Exception", context.Exception);

//                resp.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
//                context.Response = resp;
//            }
//        }

//        public static void ManageGlobalException(Exception e, HttpResponse response)
//        {
//            if (!(e is DataServiceException)) return;

//            var error = new Models.dto.Error("2002");
//            try
//            {
//                CxLog.Log(e.Message, "DSE", "", "DataService Except.", e);
//            }
//            catch (Exception ex) { error.httpMessage = ex.Message; }

//            response.ContentType = "application/json";
//            response.StatusCode = (int)HttpStatusCode.InternalServerError;
//            response.Write(JsonConvert.SerializeObject(error));
//            response.Flush();
//        }

//        private static Exception GetLastInnerException(Exception ex, Type type) {
//           var currentException = ex;
//            while (currentException != null)
//                if (currentException.GetType() == type)
//                    return currentException;
//                else
//                    currentException = currentException.InnerException;
                 
            
//            return currentException;
//        }

//    }
//}