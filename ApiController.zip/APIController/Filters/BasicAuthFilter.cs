﻿//using System;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Net;
//using System.Net.Http;
//using System.Security.Principal;
//using System.Text;
//using System.Threading;
//using System.Web.Http.Controllers;
//using System.Web.Http.Filters;
//using CxUtilities.Logger;
//using CxUtilities.Network;

//namespace APIController.Filters
//{
//    /// <summary>
//    /// Generic Basic Authentication filter that checks for basic authentication
//    /// headers and challenges for authentication if no authentication is provided
//    /// Sets the Thread Principle with a GenericAuthenticationPrincipal.
//    /// 
//    /// You can override the OnAuthorize method for custom auth logic that
//    /// might be application specific.    
//    /// </summary>
//    /// <remarks>Always remember that Basic Authentication passes username and passwords
//    /// from client to server in plain text, so make sure SSL is used with basic auth
//    /// to encode the Authorization header on all requests (not just the login).
//    /// </remarks>
//    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
//    public class BasicAuthFilter : AuthorizationFilterAttribute
//    {
//        private readonly bool _active;

//        public BasicAuthFilter()
//        {
//            _active = true;
//        }

//        /// <summary>
//        /// Overriden constructor to allow explicit disabling of this
//        /// filter's behavior. Pass false to disable (same as no filter
//        /// but declarative)
//        /// </summary>
//        /// <param name="active"></param>
//        public BasicAuthFilter(bool active)
//        {
//            _active = active;
//        }


//        /// <summary>
//        /// Override to Web API filter method to handle Basic Auth check
//        /// </summary>
//        /// <param name="actionContext"></param>
//        public override void OnAuthorization(HttpActionContext actionContext)
//        {
//            if (!_active) return;
//            //Check if the client is Allowed to connect
//            //quitar ya
//            //if (!AuthorizedConnection(actionContext))
//            //{
//            //    Forbidden(actionContext);
//            //    return;
//            //}                

//            var identity = ParseAuthorizationHeader(actionContext);
//            if (identity == null)
//            {
//                Challenge(actionContext);
//                return;
//            }


//            if (!OnAuthorizeUser(identity, actionContext))
//            {
//                Challenge(actionContext);
//                return;
//            }

//            var principal = new GenericPrincipal(identity, null);

//            Thread.CurrentPrincipal = principal;

//            // inside of ASP.NET this is also required for some async scenarios
//            //if (HttpContext.Current != null)
//            //    HttpContext.Current.User = principal;

//            base.OnAuthorization(actionContext);
//        }

//        /// <summary>
//        /// Base implementation for user authentication - you probably will
//        /// want to override this method for application specific logic.
//        /// 
//        /// The base implementation merely checks for username and password
//        /// present and set the Thread principal.
//        /// 
//        /// Override this method if you want to customize Authentication
//        /// and store user data as needed in a Thread Principle or other
//        /// Request specific storage.
//        /// </summary>
//        /// <param name="identity"></param>
//        /// <param name="actionContext"></param>
//        /// <returns></returns>
//        protected virtual bool OnAuthorizeUser(BasicAuthenticationIdentity identity, HttpActionContext actionContext)
//        {
//            if (string.IsNullOrEmpty(identity.Name) || string.IsNullOrEmpty(identity.Password))
//                return false;

//            return actionContext.Request.Headers.Authorization.Parameter == GlobalInfo.BasicAutentication;
//        }

//        /// <summary>
//        /// Parses the Authorization header and creates user credentials
//        /// </summary>
//        /// <param name="actionContext"></param>
//        protected virtual BasicAuthenticationIdentity ParseAuthorizationHeader(HttpActionContext actionContext)
//        {
//            string authHeader = null;
//            var auth = actionContext.Request.Headers.Authorization;
//            if (auth != null && auth.Scheme == "Basic")
//                authHeader = auth.Parameter;

//            if (string.IsNullOrEmpty(authHeader))
//                return null;

//            authHeader = Encoding.Default.GetString(Convert.FromBase64String(authHeader));

//            // find first : as password allows for :
//            var idx = authHeader.IndexOf(':');
//            if (idx < 0)
//                return null;

//            string username = authHeader.Substring(0, idx);
//            string password = authHeader.Substring(idx + 1);

//            return new BasicAuthenticationIdentity(username, password);
//        }


//        /// <summary>
//        /// Send the Authentication Challenge request
//        /// </summary>
//        /// <param>
//        ///     <name>actionContext</name>
//        /// </param>
//        /// <param name="actionContext"></param>
//        private void Challenge(HttpActionContext actionContext)
//        {
//            var host = actionContext.Request.RequestUri.DnsSafeHost;
//            actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
//            actionContext.Response.Headers.Add("WWW-Authenticate", "Basic realm=\""+host+"\"");
//        }

//        private void Forbidden(HttpActionContext actionContext)
//        {
//            actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Forbidden);
//        }

//        private bool AuthorizedConnection(HttpActionContext ctx)
//        {
//            var enabled = bool.Parse(ConfigurationManager.AppSettings["IP_FILTER_ENABLED"]);
//            var caller = GetCallerIp(ctx);

//            if (!enabled)
//                return true;

//            if (caller == null)
//                return false;

//            var result = false;

//            foreach (var iprange in GetAllowedIPs())
//            {
//                if (iprange.IsInRange(caller))
//                    result = true;
//            }

//            if (!result)
//                CxLog.Error("BAT", "BasicAuthFilter", new Exception("Client IP Not Allowed: " + caller + ", "));

//            return result;
//        }

//        private IEnumerable<IpAddressRange> GetAllowedIPs()
//        {
//            return GlobalInfo.AllowedIPs;
//        }

//        private IPAddress GetCallerIp(HttpActionContext context)
//        {
//            var request = System.Web.HttpContext.Current.Request;
//            var serverVariablesHttpXForwardedFor = (string)request.ServerVariables["HTTP_X_FORWARDED_FOR"];
//            var serverVariablesRemoteAddr = (string)request.ServerVariables["REMOTE_ADDR"];
//            var remoteIp = request.UserHostAddress;
//            var ip = "127.0.0.1";
//            if (!string.IsNullOrEmpty(serverVariablesHttpXForwardedFor) &&
//                !serverVariablesHttpXForwardedFor.ToLower().Contains("unknown"))
//            {
//                serverVariablesHttpXForwardedFor = serverVariablesHttpXForwardedFor.Trim();
                
//                var ipRange = serverVariablesHttpXForwardedFor.Split(',');

//                if (ipRange[0].Contains(":"))
//                    ipRange = ipRange[0].Split(':');

//                ip = ipRange[0];
//            }
//            else if (!string.IsNullOrEmpty(remoteIp))
//            {
//                if (!request.IsLocal)
//                    ip = remoteIp;
//            }
//            else if (!string.IsNullOrEmpty(serverVariablesRemoteAddr))
//            {
//                if (!request.IsLocal)
//                {
//                    serverVariablesRemoteAddr = serverVariablesRemoteAddr.Trim();
//                    ip = serverVariablesRemoteAddr;
//                }
//            }

//            IPAddress ipa;
//            IPAddress.TryParse(ip, out ipa);

//            return ipa;
//        }
//    }

//    public class BasicAuthenticationIdentity : GenericIdentity
//    {
//        public BasicAuthenticationIdentity(string name, string password)
//            : base(name, "Basic")
//        {
//            Password = password;
//        }

//        /// <summary>
//        /// Basic Auth Password for custom authentication
//        /// </summary>
//        public string Password { get; set; }

//        public bool Equals(BasicAuthenticationIdentity obj)
//        {
//            return Password == obj.Password &&
//                   Name == obj.Name;
//        }


//    }
//}