﻿//using APIController.Core;
//using System;
//using System.IO;
//using System.Net;
//using System.Net.Http;
//using System.Net.Http.Formatting;
//using System.Reflection;
//using System.Web;
//using System.Web.Http;

//namespace APIController.Controllers
//{    
//    public class DefaultController : ApiController
//    {
//        private const string SucessMessage = "Sucess!";
//        private const string FaildMessage = "Faild!";
//        private readonly MediaTypeFormatter _formatter;

//        public DefaultController()
//        {            
//            _formatter = GlobalConfiguration.Configuration.Formatters.JsonFormatter;            
//        }

//        [Route("~/v1/information")]
//        [ActionName("getInformation"), HttpGet()]
//        public HttpResponseMessage GetInformation()
//        {
//            //return Request.CreateResponse(HttpStatusCode.OK, loadAssembly("1.0.0.0"), formatter);
//            return Request.CreateResponse(HttpStatusCode.OK, GlobalInfo.SystemName, _formatter);
//        }

//        //[Route("~/v2/information")]
//        //[ActionName("getInformation"), HttpGet()]
//        //public HttpResponseMessage GetInformationV2()
//        //{
//        //    //return Request.CreateResponse(HttpStatusCode.OK, loadAssembly("1.1.0.0"), formatter);
//        //    return Request.CreateResponse(HttpStatusCode.OK, LoadAssembly("2"), _formatter);
//        //}

//        //private static string LoadAssembly(string version)
//        //{            
//        //    var assemblyPath = HttpContext.Current.Server.MapPath("~/bin/Assemblies/v" + version + "/AssemblyTest.dll");
//        //    var currentDir = HttpContext.Current.Server.MapPath("~/bin");

//        //    var f = File.AppendText(currentDir + "/result.txt");
//        //    f.WriteLine("====================================");
//        //    f.WriteLine("Time Start: " + DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss ffff"));
//        //    var assembly = Assembly.LoadFrom(assemblyPath);
//        //    f.WriteLine("Time Loaded: " + DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss ffff"));
//        //    f.WriteLine("Current dir: " + currentDir);
//        //    f.WriteLine("Loaded Assembly: " + assemblyPath);
//        //    f.WriteLine("Assembly FQN: " + assembly.FullName);

//        //    //AssemblyName asm = new AssemblyName("AssemblyTest, Version = " + n + ", Culture = neutral, PublicKeyToken = 383197dd25c43ef1");
//        //    //Assembly assembly = Assembly.Load(asm);

//        //    f.WriteLine("Time Exec: " + DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss ffff"));
//        //    var T = assembly.GetType("AssemblyTest.Test");
//        //    var m = T.GetMethod("getInformation");
//        //    var obj = Activator.CreateInstance(T);
//        //    // Execute the method.            
//        //    var result = m.Invoke(obj, null).ToString();

//        //    f.WriteLine("Time Finished: " + DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss ffff"));
//        //    f.WriteLine("Result: " + result);
//        //    f.Flush();
//        //    f.Close();

//        //    return result;
//        //}


//        //[Route("~/v1/popapipath")]
//        //[ActionName("PopApiPath"), HttpDelete()]
//        //public HttpResponseMessage PopPath(int apiPathId)
//        //{
//        //    try
//        //    {
//        //        ApiProcess.UnloadApiReference(Configuration, apiPathId);
//        //        return Request.CreateErrorResponse(HttpStatusCode.OK, SucessMessage);
//        //    }
//        //    catch (Exception)
//        //    {
//        //        return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, FaildMessage);
//        //    }
//        //}

//        //[Route("~/v1/pushapipath")]
//        //[ActionName("PushApiPath"), HttpPut()]
//        //public HttpResponseMessage PushPath(int apiPathId)
//        //{
//        //    try
//        //    {
//        //        ApiProcess.LoadApiReference(Configuration, apiPathId);
//        //        return Request.CreateErrorResponse(HttpStatusCode.OK, SucessMessage);
//        //    }
//        //    catch (Exception)
//        //    {
//        //        return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, FaildMessage);
//        //    }
//        //}

//        //[Route("~/v1/updateApiPath")]
//        //[ActionName("UpdateApiPath"), HttpPatch()]
//        //public HttpResponseMessage UpdatePath(int apiPathId)
//        //{
//        //    try
//        //    {
//        //        ApiProcess.RefreshApiReference(Configuration, apiPathId);
//        //        return Request.CreateErrorResponse(HttpStatusCode.OK, SucessMessage);
//        //    }
//        //    catch (Exception)
//        //    {
//        //        return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, FaildMessage);
//        //    }
//        //}
//    }
//}
