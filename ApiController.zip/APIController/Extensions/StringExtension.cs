﻿using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace APIController.Extensions
{
    public static class StringExtension
    {
        public static string Replace(this string source, Regex pattern, string newString)
        {
            var idx = 0;
            var mc2 = new List<Match>();
            var mc = pattern.Matches(source);
            foreach (Match m in mc)
            {
                if (m.Index >= idx)
                {
                    mc2.Insert(mc2.Count, m);
                    idx = m.Index + m.Length;
                }
            }
            foreach (Match m in mc2)
            {
                source = source.Substring(0, m.Index) + newString + source.Substring(m.Index + m.Length);
            }
            return source;
        }
    }
}