﻿using System;

namespace APIController.Models.dto
{
    [Serializable()]
    public class Error
    {
        public const string Error500 = "500";
        public const string Error500Desc = "Internal Server Error";

        public Error(string reasonCode, string moreInformation = "", string httpMessage = Error500Desc, string httpCode = Error500)
        {
            this.reasonCode = reasonCode;
            this.moreInformation = moreInformation;
            this.httpMessage = httpMessage;
            this.httpCode = httpCode;
        }

        public string httpCode { get; set; }
        public string httpMessage { get; set; }
        public string reasonCode { get; set; }
        public string moreInformation { get; set; }
    }
}