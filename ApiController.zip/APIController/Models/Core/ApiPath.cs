﻿using System;
using System.Collections.Generic;

namespace APIController.Models.Core
{

    public enum ApiPathStatus
    {        
        NotLoaded, //Not fully working, not all operations were loaded.
        NotExist, //The configured assembly was not actually present on the file system.
        Error, //The configured assembly exists on file system but there was an error while loading it
        Loaded //100% Working
    }

    public class ApiPath
    {
        public int APIPathId { get; set; }

        public string ApiCode { get; set; }

        public string APIVersion { get; set; }

        public string BusinessCapability { get; set; }

        public string URLPath { get; set; }

        public char CommandType { get; set; }

        public string SourceFQDN { get; set; }

        public string SourcePath { get; set; }

        public string ApiDescription { get; set; }

        public DateTime DateCreate { get; set; }

        public DateTime? DateUpdate { get; set; }

        public string UserCreateCode { get; set; }

        public string UserUpdateCode { get; set; }

        public string FQClassName { get; set; }

        public string ClassMethod { get; set; }

        public string ConnectionString { get; set; }

        public string HTTPMethod { get; set; }        

        //public IEnumerable<ApiParameterRel> References { get; set; }
        
        public Dictionary<string, object> PublicParams { get; set; }

        public Dictionary<string, object> PrivateParams { get; set; }

        public ApiAssemblyController ControllerRef { get; set; }

        public string ApiName => APIPathId+":"+FQClassName+"."+ClassMethod;

        public bool isAuthDisabled { get; set; }

        public bool isIPFilterDisabled { get; set; }

        public bool isAuthAzureADEnabled { get; set; }

        public ApiPathStatus Status { get; set; }
        
    }
}