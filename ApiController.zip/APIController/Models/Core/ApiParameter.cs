﻿namespace APIController.Models.Core
{
    public class ApiParameter
    {

        public int APIParameterId { get; set; }

        public string ParameterName { get; set; }

        public string ParameterDescription { get; set; }
    }
}