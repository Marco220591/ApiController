﻿//using System;
//using System.Collections.Generic;
//using System.Reflection;

//namespace APIController.Models.Core
//{
//    public class ApiReference
//    {
//        public int APIPathId { get; set; }

//        public string APIVersion { get; set; }

//        public string BusinessCapability { get; set; }

//        public string URLPath { get; set; }

//        public char CommandType { get; set; }

//        public string SourceFQDN { get; set; }

//        public string SourcePath { get; set; }

//        public string ApiDescription { get; set; }

//        public DateTime DateCreate { get; set; }

//        public DateTime? DateUpdate { get; set; }

//        public string UserCreateCode { get; set; }

//        public string UserUpdateCode { get; set; }

//        public string FQClassName { get; set; }

//        public string ClassMethod { get; set; }

//        public string ConnectionString { get; set; }

//        public string HTTPMethod { get; set; }        

//        public IEnumerable<ApiParameterRel> References { get; set; }
//    }
//}