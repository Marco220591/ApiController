﻿using System.Collections.Generic;
using System.Reflection;

namespace APIController.Models.Core
{
    public class ApiAssembly
    {
        internal Assembly AssemblyRef { get; private set; }

        //internal AppDomain DomainRef { get; private set; }

        internal ICollection<ApiAssemblyController> ApiControllers { get; set; }

        public ApiAssembly(Assembly assemblyRef)//, AppDomain domainRef)
        {
            AssemblyRef = assemblyRef;
            //DomainRef = domainRef;
        }

        public string GetPath()
        {
            return AssemblyRef.Location;
        }
    }
}