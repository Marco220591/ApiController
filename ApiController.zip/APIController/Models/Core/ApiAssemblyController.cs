﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Controllers;
using static APIController.Core.TypeActivator;

namespace APIController.Models.Core
{
    public class ApiAssemblyController
    {
        private readonly object _lock = new object();

        internal HttpControllerDescriptor Descriptor { get; private set; }

        internal void CreateControllerDescriptor(HttpConfiguration config)
        {
            lock (_lock)
            {
                var controllerDescriptor = new HttpControllerDescriptor
                {
                    Configuration = config,
                    ControllerName = FQDName,
                    ControllerType = ClassType
                };

                Descriptor = controllerDescriptor;
            }
        }


        internal ObjectActivator<IHttpController> Activator;

        internal string FQDName { get; set; }        

        internal Type ClassType { get; set; }

        internal ApiAssembly AssemblyRef { get; set; }

        public ICollection<ApiPath> ApiPaths { get; private set; }

        public void SetApiPaths(ICollection<ApiPath> value)
        {
            ApiPaths = value ?? new List<ApiPath>();
            //if (value != null)
            //{
            //    ApiPaths = value;

            //    //foreach (var path in ApiPaths)
            //    //{
            //    //    path.ControllerRef = this;
            //    //}
            //}
            //else
            //{
            //    ApiPaths = new List<ApiPath>();
            //}
        }
    }
}