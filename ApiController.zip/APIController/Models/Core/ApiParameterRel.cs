﻿namespace APIController.Models.Core
{
    public class ApiParameterRel
    {

        public int APIPathId { get; set; }

        public int APIParameterId { get; set; }

        public string IO { get; set; }

        public ApiParameter Parameter { get; set; }
    }
}