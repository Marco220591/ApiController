﻿//using Dapper;
//using System.Data.Common;
//using System.Linq;
//using System.Net.Http;
//using System.Text.RegularExpressions;
//using APIController.Extensions;
//using System.Reflection;
//using System;
//using System.Web.Http.Controllers;
//using System.Web.Http;
//using System.Collections.Generic;
//using System.Web;

//namespace APIController.Models.Core
//{
//    public class PathApiData
//    {

//        public PathApiData(ApiReference api/*, Assembly apiAssembly, Type apiClass, MethodInfo apiMethod*/)
//        {
//            string name = APIController.Core.ApiProcess.GetApiName(api);

//            Api = api;
//        }

//        public void SetHandlerData(Assembly apiAssembly)
//        {
//            Type apiClass = apiAssembly?.GetType(Api.FQClassName);

//            if (apiClass != null)
//            {
//                HandlerData = new Dictionary<string, object>();
//                HttpControllerDescriptor controllerDescriptor = new HttpControllerDescriptor();

//                controllerDescriptor.Configuration = GlobalConfiguration.Configuration;
//                controllerDescriptor.ControllerName = APIController.Core.ApiProcess.GetApiName(Api);
//                controllerDescriptor.ControllerType = apiClass;

//                HandlerData["apiClass"] = apiClass;
//                HandlerData["controllerDescriptor"] = controllerDescriptor;
//            }
//        }

//        public bool GetHandlerData(out Type apiClass, out HttpControllerDescriptor controllerDescriptor, out string errorMsg)
//        {
//            if (HandlerData != null && HandlerData.Any())
//            {
//                apiClass = HandlerData["apiClass"] as Type;
//                controllerDescriptor = HandlerData["controllerDescriptor"] as HttpControllerDescriptor;
//                errorMsg = string.Empty;
//                return true;
//            }
//            else
//            {
//                errorMsg = null;
//                HandlerData = new Dictionary<string, object>();
//            }

//            Assembly apiAssembly;
//            try
//            {
//                string path = HttpContext.Current.Server.MapPath(GlobalInfo.AssemblyDirectory + Api.SourcePath);
////#if !DEBUG
//                apiAssembly = Assembly.LoadFrom(path);
////#else
////                apiAssembly = Assembly.Load(System.IO.File.ReadAllBytes(path));
////#endif
//            }
//            catch (Exception ex)
//            {
//                errorMsg = $"Error loading the Dll '{Api.SourcePath}'";
//                apiAssembly = null;
//                while (ex != null)
//                {
//                    errorMsg = $"{errorMsg}:\r\n\r\n{ex.Message}";
//                    ex = ex.InnerException;
//                }
//            }
//            HandlerData["apiClass"] = apiClass = apiAssembly?.GetType(Api.FQClassName);
//            if (apiClass == null)
//            {
//                controllerDescriptor = null;
//                errorMsg = errorMsg ?? $"Error at get class by name '{Api.FQClassName}'";
//                HandlerData = null;
//                return false;
//            }
//            errorMsg = string.Empty;
//            HandlerData["controllerDescriptor"] = controllerDescriptor = new HttpControllerDescriptor();
//            controllerDescriptor.Configuration = GlobalConfiguration.Configuration;
//            controllerDescriptor.ControllerName = APIController.Core.ApiProcess.GetApiName(Api);
//            controllerDescriptor.ControllerType = apiClass;
//            return true;
//        }
//        public ApiReference Api { get; private set; }

//        private IDictionary<string, object> HandlerData { get; set; }
//        //public IDictionary<string, object> PublicParameters { get; private set; }
//        //public IDictionary<string, object> PrivateParameters { get; private set; }
//    }
//}